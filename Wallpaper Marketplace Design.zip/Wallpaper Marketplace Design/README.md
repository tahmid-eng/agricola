# Elsewhere — Wallpaper Atelier

A reference-inspired digital wallpaper marketplace built with React, TypeScript, Express, tRPC, Drizzle and Manus-managed MySQL. The visual direction follows the supplied travel-editorial reference: deep ultramarine, warm cream, large Cormorant Garamond display typography, textured illustrated landscapes, pill-shaped calls to action and quiet transitions.

## Application

The homepage has a four-place hero slideshow and editorial discovery sections. The catalogue contains ten original illustrated landscapes organised into five collections. Visitors can search by place, filter by collection or palette, sort, save favourites, inspect artwork in fullscreen or a mobile crop, choose a resolution and licence, and add variants to the bag. The cart stores selections on the visitor's browser when storage is available.

Checkout is deliberately a **demonstration**. It collects contact and billing form details, shows a simulated payment step, and charges no money. No card fields or payment provider are involved. Orders and line items are stored in the managed database, with all prices recomputed on the server. Billing address fields remain in the browser session, not the server's order record. The confirmation page creates downloadable JPEG files in the selected size.

The original artwork files are 2560 × 1440. Desktop 5K and 8K are resized exports; mobile uses a centre crop. The site states this explicitly. Newsletter submissions are saved, but no email campaigns or receipt emails are sent. Contact and social destinations on this concept storefront should be replaced by the actual merchant's channels before a commercial launch.

## Project structure

`client/src/pages/` contains the homepage, catalogue/collections, product, checkout, receipt, journal, story and policies. `client/src/components/` contains the shared header, bag drawer, artwork cards, newsletter and footer. `client/src/contexts/MarketContext.tsx` owns the local cart and saved artwork. `shared/market.ts` centralises resolution, licence and pricing rules.

`server/routers.ts` exposes catalogue, order and newsletter procedures. `server/db.ts` implements queries and transactional order persistence. `server/page-html.ts` provides meaningful initial public content, route-specific metadata and real not-found status before JavaScript loads. Private cart/order experiences are not indexed. `drizzle/` contains schema and additive migrations. Artwork images use durable `/manus-storage/` paths.

## Commands

Run `pnpm dev` for the port-3000 development service, `pnpm check` for TypeScript diagnostics, `pnpm test` for unit tests, and `pnpm build` for the production bundle. `pnpm start` serves the built frontend and backend. Dependencies are pinned with pnpm 10.18.0 and the lockfile.

Apply committed migrations with `pnpm db:migrate`. The catalogue seed is in `server/seed-data.ts` and `server/seed.ts`; `pnpm tsx server/seed.ts` updates the house catalogue without deleting orders. Development and production share the project's managed database, so seed or migration operations change the same data. Do not run destructive SQL for testing.

## Launch boundary

This saved version is a functional demo storefront, not a live merchant checkout. Real payments, receipt email delivery, merchant contact channels and a production licence/refund policy require merchant configuration before selling downloads for money. Shopify was not selected in the approved blueprint.
