import { useEffect } from "react";
import { Route, Switch, useLocation } from "wouter";
import { Toaster } from "@/components/ui/sonner";
import ErrorBoundary from "@/components/ErrorBoundary";
import { Header, CartDrawer, Footer } from "@/components/MarketLayout";
import { MarketProvider } from "@/contexts/MarketContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import Home from "@/pages/Home";
import { Shop, Collections, CollectionPage } from "@/pages/Catalog";
import { About, Article, Journal, Policy } from "@/pages/Editorial";
import Product from "@/pages/Product";
import Checkout from "@/pages/Checkout";
import Order from "@/pages/Order";
import NotFound from "@/pages/NotFound";
import { trpc } from "@/lib/trpc";

function ScrollToTop() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
  return null;
}
function PageMetadata() {
  const [location] = useLocation();
  const arts = trpc.catalog.wallpapers.useQuery(undefined, {
    staleTime: 60000,
  });
  const cols = trpc.catalog.collections.useQuery(undefined, {
    staleTime: 60000,
  });
  useEffect(() => {
    const names: Record<string, string> = {
      "/": "Original Art for Everyday Escapes",
      "/shop": "Find Your Elsewhere",
      "/collections": "A World in Chapters",
      "/journal": "Field Notes",
      "/about": "Our Story",
      "/saved": "Your Keepsakes",
      "/checkout": "Your Little Escape",
    };
    const art = location.startsWith("/wallpaper/")
      ? arts.data?.find(item => item.slug === location.slice(11))
      : undefined;
    const col = location.startsWith("/collection/")
      ? cols.data?.find(item => item.slug === location.slice(12))
      : undefined;
    document.title = art
      ? `${art.title} — Elsewhere Illustrated Wallpaper`
      : col
        ? `${col.name} — Elsewhere Wallpaper Collection`
        : `${names[location] || "Wallpaper Atelier"} — Elsewhere`;
    const description =
      art?.subtitle ||
      col?.tagline ||
      "Find your elsewhere. Original illustrated landscape wallpapers for desktop and mobile — from alpine mornings to Mediterranean afternoons.";
    const desc = document.querySelector<HTMLMetaElement>(
      'meta[name="description"]'
    );
    if (desc) desc.content = description;
    const ogTitle = document.querySelector<HTMLMetaElement>(
      'meta[property="og:title"]'
    );
    const ogDesc = document.querySelector<HTMLMetaElement>(
      'meta[property="og:description"]'
    );
    if (ogTitle) ogTitle.content = document.title;
    if (ogDesc) ogDesc.content = description;
    const noindex =
      location === "/checkout" ||
      location === "/saved" ||
      location === "/404" ||
      location.startsWith("/order/");
    let meta = document.querySelector<HTMLMetaElement>('meta[name="robots"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "robots";
      document.head.append(meta);
    }
    meta.content = noindex ? "noindex, nofollow" : "index, follow";
  }, [location, arts.data, cols.data]);
  return null;
}
function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/shop">
        <Shop />
      </Route>
      <Route path="/saved">
        <Shop savedOnly />
      </Route>
      <Route path="/collections" component={Collections} />
      <Route path="/collection/:slug">
        {params => <CollectionPage slug={params.slug} />}
      </Route>
      <Route path="/wallpaper/:slug">
        {params => <Product slug={params.slug} />}
      </Route>
      <Route path="/checkout" component={Checkout} />
      <Route path="/order/:reference">
        {params => <Order reference={params.reference} />}
      </Route>
      <Route path="/journal" component={Journal} />
      <Route path="/journal/:slug">
        {params => <Article slug={params.slug} />}
      </Route>
      <Route path="/about" component={About} />
      <Route path="/policies/:slug">
        {params => <Policy slug={params.slug} />}
      </Route>
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}
export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <MarketProvider>
          <ScrollToTop />
          <PageMetadata />
          <Header />
          <Router />
          <Footer />
          <CartDrawer />
          <Toaster position="bottom-center" />
        </MarketProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
