import { Link } from "wouter";
import { ArrowUpRight, Heart } from "lucide-react";
import { useMarket } from "@/contexts/MarketContext";
import { formatPrice } from "@shared/market";
import type { Wallpaper } from "@/lib/types";

export default function ArtCard({
  art,
  number,
  compact = false,
}: {
  art: Wallpaper;
  number?: number;
  compact?: boolean;
}) {
  const { saved, toggleSaved } = useMarket();
  const kept = saved.includes(art.slug);
  return (
    <article className={`art-card ${compact ? "compact" : ""}`}>
      <div className="art-card-image">
        <Link href={`/wallpaper/${art.slug}`} aria-label={`View ${art.title}`}>
          <img
            src={art.thumb || art.image}
            alt={`Illustrated landscape of ${art.location}`}
            loading="lazy"
          />
          <div className="art-card-hover">
            <span>Take a closer look</span>
            <ArrowUpRight size={22} />
          </div>
        </Link>
        <button
          className={`save-art ${kept ? "saved" : ""}`}
          aria-label={kept ? `Unsave ${art.title}` : `Save ${art.title}`}
          aria-pressed={kept}
          onClick={() => toggleSaved(art.slug)}
        >
          <Heart
            size={17}
            fill={kept ? "currentColor" : "none"}
            strokeWidth={1.5}
          />
        </button>
        {number !== undefined && (
          <span className="art-number">{String(number).padStart(2, "0")}</span>
        )}
      </div>
      <div className="art-card-meta">
        <div>
          <p className="eyebrow">{art.collectionName}</p>
          <Link href={`/wallpaper/${art.slug}`}>
            <h3>{art.title}</h3>
          </Link>
          <p className="art-card-location">{art.location}</p>
        </div>
        <div className="art-price">
          <small>FROM</small>
          <span>{formatPrice(art.basePriceCents)}</span>
        </div>
      </div>
    </article>
  );
}
