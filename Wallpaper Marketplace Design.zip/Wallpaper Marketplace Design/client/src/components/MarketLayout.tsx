import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  Heart,
  Minus,
  Plus,
  ShoppingBag,
  X,
} from "lucide-react";
import { useMarket } from "@/contexts/MarketContext";
import { trpc } from "@/lib/trpc";
import {
  computeUnitPriceCents,
  formatPrice,
  licenseById,
  resolutionById,
} from "@shared/market";

export function Header() {
  const [location] = useLocation();
  const { count, setDrawerOpen } = useMarket();
  const [menu, setMenu] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const home = location === "/";
  useEffect(() => {
    const handle = () => setScrolled(window.scrollY > 40);
    handle();
    window.addEventListener("scroll", handle, { passive: true });
    return () => window.removeEventListener("scroll", handle);
  }, []);
  useEffect(() => setMenu(false), [location]);
  useEffect(() => {
    if (!menu) return;
    const close = (e: KeyboardEvent) => e.key === "Escape" && setMenu(false);
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [menu]);
  return (
    <>
      <header
        className={`site-header ${home && !scrolled && !menu ? "over-hero" : "solid-header"}`}
      >
        <Link href="/" className="wordmark" aria-label="Elsewhere home">
          elsewhere<span>.</span>
        </Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          <Link href="/shop">Wallpapers.</Link>
          <Link href="/collections">Collections.</Link>
          <Link href="/journal">Journal.</Link>
          <Link href="/about">Our Story.</Link>
        </nav>
        <div className="header-actions">
          <button
            className="bag-button"
            onClick={() => setDrawerOpen(true)}
            aria-label={`Open bag with ${count} items`}
          >
            <ShoppingBag size={17} />
            <span>Bag ({count})</span>
          </button>
          <Link className="button nav-cta" href="/shop">
            Find your elsewhere <ArrowUpRight size={15} />
          </Link>
          <button
            className={`menu-toggle ${menu ? "is-open" : ""}`}
            onClick={() => setMenu(!menu)}
            aria-expanded={menu}
            aria-label={menu ? "Close menu" : "Open menu"}
          >
            <span />
            <span />
          </button>
        </div>
      </header>
      {menu && (
        <div className="menu-overlay">
          <div className="eyebrow">A LITTLE WAY OUT</div>
          <nav aria-label="Expanded navigation">
            {[
              ["/shop", "The wallpapers"],
              ["/collections", "The collections"],
              ["/journal", "Field notes"],
              ["/about", "Our story"],
              ["/saved", "Your keepsakes"],
            ].map(([href, title], i) => (
              <Link href={href} key={href}>
                <small>0{i + 1}</small>
                {title}
                <ArrowUpRight />
              </Link>
            ))}
          </nav>
          <p>Not every escape needs a plane ticket.</p>
        </div>
      )}
    </>
  );
}

export function CartDrawer() {
  const {
    cart,
    count,
    totalCents,
    drawerOpen,
    setDrawerOpen,
    removeFromCart,
    updateQuantity,
  } = useMarket();
  const [, navigate] = useLocation();
  useEffect(() => {
    if (!drawerOpen) return;
    const prior = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const close = (e: KeyboardEvent) =>
      e.key === "Escape" && setDrawerOpen(false);
    window.addEventListener("keydown", close);
    return () => {
      document.body.style.overflow = prior;
      window.removeEventListener("keydown", close);
    };
  }, [drawerOpen, setDrawerOpen]);
  if (!drawerOpen) return null;
  return (
    <div className="drawer-backdrop" onClick={() => setDrawerOpen(false)}>
      <aside
        className="cart-drawer"
        role="dialog"
        aria-modal="true"
        aria-label="Your bag"
        onClick={e => e.stopPropagation()}
      >
        <div className="drawer-head">
          <div>
            <p className="eyebrow">GOOD PLACES, TO GO</p>
            <h2>
              Your bag <sup>({count})</sup>
            </h2>
          </div>
          <button
            className="circle-button"
            aria-label="Close bag"
            onClick={() => setDrawerOpen(false)}
          >
            <X size={20} />
          </button>
        </div>
        {cart.length ? (
          <>
            <div className="drawer-items">
              {cart.map(row => (
                <div className="cart-row" key={row.key}>
                  <Link
                    href={`/wallpaper/${row.slug}`}
                    onClick={() => setDrawerOpen(false)}
                  >
                    <img src={row.thumb || row.image} alt={row.title} />
                  </Link>
                  <div className="cart-row-copy">
                    <h3>{row.title}</h3>
                    <p>
                      {resolutionById(row.resolution).label} ·{" "}
                      {licenseById(row.license).label}
                    </p>
                    <div className="cart-row-bottom">
                      <div className="quantity-control">
                        <button
                          aria-label={`Decrease ${row.title} quantity`}
                          onClick={() =>
                            updateQuantity(row.key, row.quantity - 1)
                          }
                        >
                          <Minus size={12} />
                        </button>
                        <span>{row.quantity}</span>
                        <button
                          aria-label={`Increase ${row.title} quantity`}
                          onClick={() =>
                            updateQuantity(row.key, row.quantity + 1)
                          }
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                      <span>
                        {formatPrice(
                          computeUnitPriceCents(
                            row.basePriceCents,
                            row.resolution,
                            row.license
                          ) * row.quantity
                        )}
                      </span>
                    </div>
                    <button
                      className="text-remove"
                      onClick={() => removeFromCart(row.key)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <div className="drawer-total">
              <div>
                <span>Subtotal</span>
                <strong>{formatPrice(totalCents)}</strong>
              </div>
              <p>Digital files. No shipping. A world of possibility.</p>
              <button
                className="button button-blue full-width"
                onClick={() => {
                  setDrawerOpen(false);
                  navigate("/checkout");
                }}
              >
                Continue to checkout <ArrowRight size={16} />
              </button>
              <small>Demo checkout · no money is charged</small>
            </div>
          </>
        ) : (
          <div className="empty-bag">
            <ShoppingBag size={34} strokeWidth={1} />
            <h3>A little room for somewhere.</h3>
            <p>Your bag is empty. Find a view worth keeping.</p>
            <Link
              href="/shop"
              className="button button-blue"
              onClick={() => setDrawerOpen(false)}
            >
              Explore the wallpapers <ArrowRight size={16} />
            </Link>
          </div>
        )}
      </aside>
    </div>
  );
}

export function Newsletter() {
  const [email, setEmail] = useState("");
  const subscribe = trpc.newsletter.subscribe.useMutation();
  return (
    <section className="newsletter">
      <div>
        <p className="eyebrow">POSTCARDS, NOT SPAM</p>
        <h2>
          A little elsewhere.
          <br />
          <em>In your inbox.</em>
        </h2>
      </div>
      <div className="newsletter-right">
        <p>
          New places, fresh prints, and the occasional field note.
          <br />
          Sent slowly. Worth opening.
        </p>
        {subscribe.isSuccess ? (
          <div className="newsletter-success">
            <Check size={20} /> You're on the list. See you somewhere.
          </div>
        ) : (
          <form
            onSubmit={e => {
              e.preventDefault();
              subscribe.mutate({ email });
            }}
          >
            <label className="sr-only" htmlFor="newsletter-email">
              Email address
            </label>
            <input
              id="newsletter-email"
              type="email"
              placeholder="Your email address"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
            <button
              disabled={subscribe.isPending}
              aria-label="Join the newsletter"
            >
              <ArrowUpRight size={24} />
            </button>
          </form>
        )}
        {subscribe.isError && (
          <p className="form-error">{subscribe.error.message}</p>
        )}
        <small>
          By signing up, you agree to our{" "}
          <Link href="/policies/privacy">Privacy Policy</Link>.
        </small>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-top">
        <div>
          <Link href="/" className="wordmark">
            elsewhere<span>.</span>
          </Link>
          <p>
            For the places your mind wanders.
            <br />
            Original art. A different kind of wallpaper.
          </p>
          <div className="footer-social">
            <a
              href="https://www.instagram.com/"
              target="_blank"
              rel="noopener noreferrer"
            >
              Instagram ↗
            </a>
            <a
              href="https://www.pinterest.com/"
              target="_blank"
              rel="noopener noreferrer"
            >
              Pinterest ↗
            </a>
          </div>
        </div>
        <div className="footer-links">
          <div>
            <p className="eyebrow">WANDER</p>
            <Link href="/shop">All wallpapers</Link>
            <Link href="/collections">The collections</Link>
            <Link href="/saved">Your keepsakes</Link>
          </div>
          <div>
            <p className="eyebrow">THE ATELIER</p>
            <Link href="/about">Our story</Link>
            <Link href="/journal">Field notes</Link>
            <a href="mailto:hello@elsewhere.studio">Say hello ↗</a>
          </div>
          <div>
            <p className="eyebrow">THE DETAILS</p>
            <Link href="/policies/licensing">Licensing & usage</Link>
            <Link href="/policies/faq">Questions & answers</Link>
            <Link href="/policies/privacy">Privacy</Link>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Elsewhere Atelier</span>
        <span>Made for the beautifully distracted.</span>
        <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
          BACK TO THE TOP{" "}
          <ArrowDown size={13} style={{ transform: "rotate(180deg)" }} />
        </button>
      </div>
    </footer>
  );
}

export function LoadingState({
  text = "Finding your elsewhere…",
}: {
  text?: string;
}) {
  return (
    <div className="page-state">
      <span className="loading-orbit" />
      <p>{text}</p>
    </div>
  );
}
export function ErrorState({ retry }: { retry: () => void }) {
  return (
    <div className="page-state">
      <h2>A little detour.</h2>
      <p>We couldn't reach the atelier. Please try again.</p>
      <button className="button button-blue" onClick={retry}>
        Try again <ArrowRight size={16} />
      </button>
    </div>
  );
}
