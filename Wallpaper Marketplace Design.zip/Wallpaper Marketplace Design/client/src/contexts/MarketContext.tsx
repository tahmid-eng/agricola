import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import type { LicenceId, ResolutionId } from "../lib/types";
import { computeUnitPriceCents } from "@shared/market";
import { toast } from "sonner";

export type CartItem = {
  key: string;
  slug: string;
  title: string;
  image: string;
  thumb: string | null;
  location: string | null;
  collectionName: string | null;
  basePriceCents: number;
  resolution: ResolutionId;
  license: LicenceId;
  quantity: number;
};

export type AddCartItem = Omit<CartItem, "key" | "quantity">;

type MarketStore = {
  cart: CartItem[];
  count: number;
  totalCents: number;
  saved: string[];
  drawerOpen: boolean;
  setDrawerOpen: (open: boolean) => void;
  addToCart: (item: AddCartItem) => void;
  removeFromCart: (key: string) => void;
  updateQuantity: (key: string, quantity: number) => void;
  clearCart: () => void;
  toggleSaved: (slug: string) => void;
};

const MarketContext = createContext<MarketStore | null>(null);
const CART_KEY = "elsewhere-cart-v1";
const SAVED_KEY = "elsewhere-saved-v1";

function readStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

export function MarketProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => readStored(CART_KEY, []));
  const [saved, setSaved] = useState<string[]>(() => readStored(SAVED_KEY, []));
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch {
      /* Private browsers can block embedded storage. */
    }
  }, [cart]);
  useEffect(() => {
    try {
      localStorage.setItem(SAVED_KEY, JSON.stringify(saved));
    } catch {
      /* Keep this visit functional without persistence. */
    }
  }, [saved]);

  const addToCart = useCallback((item: AddCartItem) => {
    const key = `${item.slug}:${item.resolution}:${item.license}`;
    setCart(current => {
      const existing = current.find(row => row.key === key);
      if (existing) {
        return current.map(row =>
          row.key === key
            ? { ...row, quantity: Math.min(row.quantity + 1, 10) }
            : row
        );
      }
      return [...current, { ...item, key, quantity: 1 }];
    });
    setDrawerOpen(true);
  }, []);

  const removeFromCart = useCallback((key: string) => {
    setCart(current => current.filter(row => row.key !== key));
  }, []);

  const updateQuantity = useCallback((key: string, quantity: number) => {
    if (quantity <= 0) {
      setCart(current => current.filter(row => row.key !== key));
    } else {
      setCart(current =>
        current.map(row =>
          row.key === key ? { ...row, quantity: Math.min(quantity, 10) } : row
        )
      );
    }
  }, []);

  const toggleSaved = useCallback((slug: string) => {
    setSaved(current => {
      const exists = current.includes(slug);
      toast(
        exists
          ? "Removed from your keepsakes."
          : "A little place to come back to."
      );
      return exists
        ? current.filter(value => value !== slug)
        : [...current, slug];
    });
  }, []);

  const value = useMemo<MarketStore>(
    () => ({
      cart,
      count: cart.reduce((sum, row) => sum + row.quantity, 0),
      totalCents: cart.reduce(
        (sum, row) =>
          sum +
          computeUnitPriceCents(
            row.basePriceCents,
            row.resolution,
            row.license
          ) *
            row.quantity,
        0
      ),
      saved,
      drawerOpen,
      setDrawerOpen,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart: () => setCart([]),
      toggleSaved,
    }),
    [
      cart,
      saved,
      drawerOpen,
      addToCart,
      removeFromCart,
      updateQuantity,
      toggleSaved,
    ]
  );

  return (
    <MarketContext.Provider value={value}>{children}</MarketContext.Provider>
  );
}

export function useMarket() {
  const store = useContext(MarketContext);
  if (!store) throw new Error("useMarket must be called within MarketProvider");
  return store;
}
