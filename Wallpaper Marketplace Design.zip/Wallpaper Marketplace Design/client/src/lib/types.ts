import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../server/routers";
import type {
  LicenseId,
  ResolutionId as SharedResolutionId,
} from "@shared/market";

type Outputs = inferRouterOutputs<AppRouter>;
export type Wallpaper = Outputs["catalog"]["wallpapers"][number];
export type Collection = Outputs["catalog"]["collections"][number];
export type OrderResult = Outputs["orders"]["get"];
export type ResolutionId = SharedResolutionId;
export type LicenceId = LicenseId;
