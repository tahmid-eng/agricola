import { useMemo, useState } from "react";
import { Link } from "wouter";
import {
  ArrowRight,
  ArrowUpRight,
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import ArtCard from "@/components/ArtCard";
import {
  ErrorState,
  LoadingState,
  Newsletter,
} from "@/components/MarketLayout";
import { useMarket } from "@/contexts/MarketContext";
import { PALETTES } from "@shared/market";
import NotFound from "./NotFound";

export function Shop({ savedOnly = false }: { savedOnly?: boolean }) {
  const arts = trpc.catalog.wallpapers.useQuery();
  const cols = trpc.catalog.collections.useQuery();
  const { saved } = useMarket();
  const [category, setCategory] = useState("all");
  const [palette, setPalette] = useState("");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("atelier");
  const [filters, setFilters] = useState(true);
  const filtered = useMemo(() => {
    const values = (arts.data || []).filter(
      art =>
        (!savedOnly || saved.includes(art.slug)) &&
        (category === "all" || art.collectionSlug === category) &&
        (!palette || art.palettes.split(",").includes(palette)) &&
        (!search ||
          [art.title, art.location, art.collectionName, art.subtitle].some(
            value => value?.toLowerCase().includes(search.trim().toLowerCase())
          ))
    );
    if (sort === "low")
      values.sort((a, b) => a.basePriceCents - b.basePriceCents);
    if (sort === "high")
      values.sort((a, b) => b.basePriceCents - a.basePriceCents);
    if (sort === "name") values.sort((a, b) => a.title.localeCompare(b.title));
    if (sort === "new") values.sort((a, b) => b.sortOrder - a.sortOrder);
    return values;
  }, [arts.data, category, palette, search, sort, saved, savedOnly]);
  return (
    <main className="catalog-page">
      <section className="page-intro">
        <p className="eyebrow">
          {savedOnly
            ? "A LITTLE PLACE TO COME BACK TO"
            : "YOUR NEXT LITTLE ESCAPE"}
        </p>
        <h1>
          {savedOnly ? (
            <>
              Your <em>keepsakes.</em>
            </>
          ) : (
            <>
              Find your <em>elsewhere.</em>
            </>
          )}
        </h1>
        <p>
          {savedOnly
            ? "The views you loved enough to keep."
            : "From alpine mornings to endless summer afternoons.\nA world of original art, made for your screen."}
        </p>
      </section>
      <section className="shop-section">
        <div className="shop-topbar">
          <div className="collection-tabs">
            <button
              className={category === "all" ? "active" : ""}
              onClick={() => setCategory("all")}
            >
              All places <sup>{arts.data?.length ?? "—"}</sup>
            </button>
            {cols.data?.map(col => (
              <button
                key={col.id}
                className={category === col.slug ? "active" : ""}
                onClick={() => setCategory(col.slug)}
              >
                {col.name.replace("The ", "")}
              </button>
            ))}
          </div>
          <button
            className={`filter-toggle ${filters ? "active" : ""}`}
            onClick={() => setFilters(!filters)}
          >
            <SlidersHorizontal size={15} /> Refine
          </button>
        </div>
        <div className={`shop-refine ${filters ? "expanded" : ""}`}>
          <div className="palette-filter">
            <span className="eyebrow">A COLOUR FEELING</span>
            {PALETTES.map(p => (
              <button
                key={p.id}
                title={p.label}
                aria-label={`Filter ${p.label}`}
                aria-pressed={palette === p.id}
                className={palette === p.id ? "selected" : ""}
                onClick={() => setPalette(palette === p.id ? "" : p.id)}
              >
                <span style={{ backgroundColor: p.swatch }} />
                {p.label}
              </button>
            ))}
          </div>
          <div className="shop-search">
            <Search size={16} />
            <input
              aria-label="Search wallpapers"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Somewhere in mind?"
            />
            {search && (
              <button aria-label="Clear search" onClick={() => setSearch("")}>
                <X size={14} />
              </button>
            )}
          </div>
        </div>
        <div className="shop-results-line">
          <span>
            {arts.isLoading
              ? "FINDING YOUR ELSEWHERE"
              : `${filtered.length} ${filtered.length === 1 ? "PLACE" : "PLACES"} TO GET LOST IN`}{" "}
            {palette && (
              <button onClick={() => setPalette("")} className="clear-filter">
                {palette} ×
              </button>
            )}
          </span>
          <label>
            SORT BY{" "}
            <select
              value={sort}
              onChange={e => setSort(e.target.value)}
              aria-label="Sort wallpapers"
            >
              <option value="atelier">Atelier picks</option>
              <option value="new">Newest first</option>
              <option value="low">Price: low to high</option>
              <option value="high">Price: high to low</option>
              <option value="name">Name: A–Z</option>
            </select>
          </label>
        </div>
        {arts.isLoading ? (
          <LoadingState />
        ) : arts.isError ? (
          <ErrorState retry={() => arts.refetch()} />
        ) : filtered.length ? (
          <div className="art-grid shop-grid">
            {filtered.map((art, i) => (
              <ArtCard key={art.id} art={art} number={i + 1} />
            ))}
          </div>
        ) : (
          <div className="empty-results">
            <h2>
              {savedOnly
                ? "A view worth keeping is out there."
                : "A little further off the map."}
            </h2>
            <p>
              {savedOnly
                ? "Tap the heart on an artwork to save it here."
                : "No places match just yet. Try another colour or a different word."}
            </p>
            {savedOnly ? (
              <Link href="/shop" className="button button-blue">
                Explore the wallpapers <ArrowRight size={16} />
              </Link>
            ) : (
              <button
                className="button button-blue"
                onClick={() => {
                  setCategory("all");
                  setPalette("");
                  setSearch("");
                }}
              >
                Clear the filters <ArrowRight size={16} />
              </button>
            )}
          </div>
        )}
      </section>
      <Newsletter />
    </main>
  );
}

export function Collections() {
  const query = trpc.catalog.collections.useQuery();
  return (
    <main className="collections-page">
      <section className="page-intro">
        <p className="eyebrow">A WORLD, IN CHAPTERS</p>
        <h1>
          Follow your <em>feeling.</em>
        </h1>
        <p>
          Some places belong together. Five small journeys,\neach with its own
          light, colour, and way of slowing time.
        </p>
      </section>
      {query.isLoading ? (
        <LoadingState />
      ) : query.isError ? (
        <ErrorState retry={() => query.refetch()} />
      ) : (
        <div className="collection-list">
          {query.data?.map((col, i) => (
            <Link
              key={col.id}
              href={`/collection/${col.slug}`}
              className={`collection-editorial ${i % 2 ? "reverse" : ""}`}
            >
              <div className="collection-editorial-image">
                <img
                  src={col.heroImage || ""}
                  alt={`Illustrated landscape for ${col.name}`}
                  loading="lazy"
                />
                <span>{col.coordinates}</span>
              </div>
              <div className="collection-editorial-copy">
                <p className="eyebrow">{col.chapter}</p>
                <h2>{col.name}</h2>
                <p>{col.tagline}</p>
                <span className="line-link dark-link">
                  Wander this chapter <ArrowUpRight size={17} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
      <Newsletter />
    </main>
  );
}

export function CollectionPage({ slug }: { slug: string }) {
  const query = trpc.catalog.collection.useQuery({ slug });
  if (query.isLoading) return <LoadingState />;
  if (query.isError) {
    if (query.error.data?.code === "NOT_FOUND") return <NotFound />;
    return <ErrorState retry={() => query.refetch()} />;
  }
  if (!query.data) return null;
  const { collection, wallpapers } = query.data;
  return (
    <main className="collection-page">
      <section className="collection-hero">
        <img src={collection.heroImage || ""} alt={collection.name} />
        <div className="collection-hero-shade" />
        <div>
          <Link href="/collections" className="eyebrow">
            ← ALL CHAPTERS
          </Link>
          <p className="eyebrow">{collection.chapter}</p>
          <h1>{collection.name}</h1>
          <p>{collection.tagline}</p>
          <span>
            {collection.location} · {collection.coordinates}
          </span>
        </div>
      </section>
      <section className="collection-intro">
        <p className="eyebrow">A NOTE FROM THE ATELIER</p>
        <p>{collection.description}</p>
      </section>
      <section className="featured-section">
        <div className="section-heading">
          <h2>The places in this chapter.</h2>
          <span className="eyebrow">{wallpapers.length} ORIGINAL ARTWORKS</span>
        </div>
        <div className="art-grid collection-grid">
          {wallpapers.map((art, i) => (
            <ArtCard key={art.id} art={art} number={i + 1} />
          ))}
        </div>
      </section>
      <Newsletter />
    </main>
  );
}
