import { useMarket } from "@/contexts/MarketContext";
import { trpc } from "@/lib/trpc";
import type { LicenceId, ResolutionId } from "@/lib/types";
import {
  computeUnitPriceCents,
  formatPrice,
  licenseById,
  resolutionById,
} from "@shared/market";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Check,
  CreditCard,
  Loader2,
  Lock,
  ShoppingBag,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useLocation } from "wouter";

type Step = "contact" | "payment";

type ContactFields = {
  name: string;
  email: string;
  country: string;
  address: string;
  city: string;
  postalCode: string;
};

const EMPTY_FIELDS: ContactFields = {
  name: "",
  email: "",
  country: "",
  address: "",
  city: "",
  postalCode: "",
};

const STEPS: { id: Step; label: string }[] = [
  { id: "contact", label: "Contact & billing" },
  { id: "payment", label: "Payment" },
];

function isNotFound(error: unknown) {
  const code = (error as { data?: { code?: string } } | null)?.data?.code;
  return code === "NOT_FOUND";
}

export default function Checkout() {
  const { cart, clearCart } = useMarket();
  const catalog = trpc.catalog.wallpapers.useQuery();
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<Step>("contact");
  const [fields, setFields] = useState<ContactFields>(EMPTY_FIELDS);
  const [completed, setCompleted] = useState(false);

  const summary = useMemo(
    () =>
      cart.map(row => ({
        ...row,
        unitPriceCents: computeUnitPriceCents(
          catalog.data?.find(art => art.slug === row.slug)?.basePriceCents ??
            row.basePriceCents,
          row.resolution as ResolutionId,
          row.license as LicenceId
        ),
      })),
    [cart, catalog.data]
  );
  const totalCents = summary.reduce(
    (sum, row) => sum + row.unitPriceCents * row.quantity,
    0
  );

  const createOrder = trpc.orders.create.useMutation({
    onError: error => {
      if (error.data?.code === "CONFLICT") catalog.refetch();
    },
    onSuccess: result => {
      try {
        sessionStorage.setItem(
          `elsewhere-order-${result.reference}`,
          JSON.stringify({
            reference: result.reference,
            placedAt: new Date().toISOString(),
            customer: {
              name: fields.name.trim(),
              email: fields.email.trim(),
              country: fields.country.trim(),
            },
            billing: {
              address: fields.address.trim(),
              city: fields.city.trim(),
              postalCode: fields.postalCode.trim(),
            },
            totalCents: result.totalCents,
          })
        );
      } catch {
        // Storage can be blocked; the receipt itself still comes from the server.
      }
      setCompleted(true);
      clearCart();
      setLocation(`/order/${result.reference}`);
    },
  });

  const updateField =
    (key: keyof ContactFields) =>
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const { value } = event.target;
      setFields(current => ({ ...current, [key]: value }));
    };

  const handleContactSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!event.currentTarget.checkValidity()) return;
    setStep("payment");
  };

  const handlePlaceOrder = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (createOrder.isPending || cart.length === 0) return;
    createOrder.mutate({
      expectedTotalCents: totalCents,
      customer: {
        name: fields.name.trim(),
        email: fields.email.trim(),
        country: fields.country.trim(),
      },
      items: cart.map(row => ({
        slug: row.slug,
        resolution: row.resolution as ResolutionId,
        license: row.license as LicenceId,
        quantity: row.quantity,
      })),
    });
  };

  if (cart.length === 0 && !completed) {
    return (
      <div className="commerce-page checkout-page">
        <p className="eyebrow">Checkout</p>
        <h1 className="display-title">Nothing to wrap yet</h1>
        <div className="notice" role="status">
          <ShoppingBag aria-hidden="true" />
          <p>
            Your cart is empty. Choose a place first, then come back and
            we&apos;ll get it sent.
          </p>
        </div>
        <div className="button-row">
          <Link href="/" className="button button-blue">
            <ArrowLeft aria-hidden="true" /> Browse the archive
          </Link>
        </div>
      </div>
    );
  }

  if (completed) {
    return (
      <div className="commerce-page checkout-page" aria-busy="true">
        <p className="notice">
          <Loader2 className="icon-spin" aria-hidden="true" /> Opening your
          receipt…
        </p>
      </div>
    );
  }

  const orderError = createOrder.error;
  const errorMessage = orderError
    ? isNotFound(orderError) ||
      orderError.data?.code === "BAD_REQUEST" ||
      orderError.data?.code === "CONFLICT"
      ? orderError.message
      : "We couldn't open your order just now. Nothing was charged — please try again."
    : null;

  return (
    <div className="commerce-page checkout-page">
      <header className="checkout-head">
        <p className="eyebrow">Checkout</p>
        <h1 className="display-title">Almost yours</h1>
        <p className="lead">
          Two short steps. No account, no card details — this is a demonstration
          checkout.
        </p>
      </header>

      <ol className="checkout-steps" aria-label="Checkout progress">
        {STEPS.map((entry, index) => {
          const active = entry.id === step;
          const done = entry.id === "contact" && step === "payment";
          return (
            <li key={entry.id} aria-current={active ? "step" : undefined}>
              <span className="step-number" aria-hidden="true">
                {done ? <Check aria-hidden="true" /> : index + 1}
              </span>
              <span className="step-label">{entry.label}</span>
            </li>
          );
        })}
      </ol>

      <div className="checkout-layout">
        <div className="checkout-main">
          {step === "contact" ? (
            <form className="form-grid" onSubmit={handleContactSubmit}>
              <h2 className="section-heading">Where should the licence go?</h2>

              <div className="field">
                <label htmlFor="checkout-name">Full name</label>
                <input
                  id="checkout-name"
                  name="name"
                  type="text"
                  autoComplete="name"
                  required
                  minLength={2}
                  maxLength={120}
                  value={fields.name}
                  onChange={updateField("name")}
                  aria-describedby="checkout-name-hint"
                />
                <p id="checkout-name-hint" className="field-hint">
                  The name printed on the licence.
                </p>
              </div>

              <div className="field">
                <label htmlFor="checkout-email">Email</label>
                <input
                  id="checkout-email"
                  name="email"
                  type="email"
                  inputMode="email"
                  autoComplete="email"
                  required
                  maxLength={320}
                  value={fields.email}
                  onChange={updateField("email")}
                  aria-describedby="checkout-email-hint"
                />
                <p id="checkout-email-hint" className="field-hint">
                  Stored with your demo order; no email is sent.
                </p>
              </div>

              <div className="field">
                <label htmlFor="checkout-country">Country</label>
                <input
                  id="checkout-country"
                  name="country"
                  type="text"
                  autoComplete="country-name"
                  required
                  minLength={2}
                  maxLength={96}
                  value={fields.country}
                  onChange={updateField("country")}
                />
              </div>

              <h2 className="section-heading">Billing address</h2>

              <div className="field">
                <label htmlFor="checkout-address">Street address</label>
                <input
                  id="checkout-address"
                  name="address"
                  autoComplete="street-address"
                  required
                  minLength={3}
                  maxLength={160}
                  value={fields.address}
                  onChange={updateField("address")}
                />
              </div>
              <div className="field-grid">
                <div className="field">
                  <label htmlFor="checkout-city">City</label>
                  <input
                    id="checkout-city"
                    name="city"
                    type="text"
                    autoComplete="address-level2"
                    required
                    minLength={2}
                    maxLength={96}
                    value={fields.city}
                    onChange={updateField("city")}
                  />
                </div>

                <div className="field">
                  <label htmlFor="checkout-postal">Postal code</label>
                  <input
                    id="checkout-postal"
                    name="postalCode"
                    type="text"
                    autoComplete="postal-code"
                    required
                    minLength={2}
                    maxLength={16}
                    value={fields.postalCode}
                    onChange={updateField("postalCode")}
                  />
                </div>
              </div>

              <div className="button-row">
                <button type="submit" className="button button-blue">
                  Continue to payment <ArrowRight aria-hidden="true" />
                </button>
              </div>
              <p className="notice">
                <Lock aria-hidden="true" /> Your details are used for this order
                only. Billing fields stay in this browser session; no payment
                details are collected.
              </p>
            </form>
          ) : (
            <form className="form-grid" onSubmit={handlePlaceOrder}>
              <h2 className="section-heading">Payment</h2>

              <div
                className="demo-card"
                role="img"
                aria-label="Demonstration payment card ending 4242 — not a real card"
              >
                <div className="demo-card-top">
                  <CreditCard aria-hidden="true" />
                  <span>Demo card</span>
                </div>
                <p className="demo-card-number">4242 4242 4242 4242</p>
                <div className="demo-card-meta">
                  <span>ELSEWHERE ATELIER</span>
                  <span>12 / 30</span>
                </div>
              </div>

              <p className="notice" role="note">
                <AlertCircle aria-hidden="true" />
                <strong>Demo checkout — no money is charged.</strong> No card
                details are requested, stored or sent. Placing this order only
                records it so you can try the download flow.
              </p>

              <div className="detail-list">
                <div className="detail-row">
                  <dt>Name</dt>
                  <dd>{fields.name.trim()}</dd>
                </div>
                <div className="detail-row">
                  <dt>Email</dt>
                  <dd>{fields.email.trim()}</dd>
                </div>
                <div className="detail-row">
                  <dt>Billing</dt>
                  <dd>
                    {fields.address.trim()}, {fields.city.trim()},{" "}
                    {fields.postalCode.trim()} · {fields.country.trim()}
                  </dd>
                </div>
              </div>

              {errorMessage ? (
                <p className="notice notice-error" role="alert">
                  <AlertCircle aria-hidden="true" /> {errorMessage}
                </p>
              ) : null}

              <div className="button-row">
                <button
                  type="submit"
                  className="button button-blue"
                  disabled={createOrder.isPending}
                  aria-busy={createOrder.isPending}
                >
                  {createOrder.isPending ? (
                    <>
                      <Loader2 className="icon-spin" aria-hidden="true" />{" "}
                      Opening your order…
                    </>
                  ) : (
                    <>Place demo order — {formatPrice(totalCents)}</>
                  )}
                </button>
                <button
                  type="button"
                  className="button button-outline"
                  onClick={() => setStep("contact")}
                  disabled={createOrder.isPending}
                >
                  <ArrowLeft aria-hidden="true" /> Back to details
                </button>
              </div>
            </form>
          )}
        </div>

        <aside className="order-summary" aria-labelledby="summary-heading">
          <h2 id="summary-heading" className="section-heading">
            Your order
          </h2>
          <ul className="order-list">
            {summary.map(row => (
              <li key={row.key} className="order-row">
                <img
                  src={row.thumb ?? row.image}
                  alt=""
                  width={96}
                  height={54}
                  loading="lazy"
                />
                <div className="order-row-body">
                  <p className="order-row-title">{row.title}</p>
                  <p className="order-row-meta">
                    {resolutionById(row.resolution).label} ·{" "}
                    {licenseById(row.license).label} licence
                    {row.quantity > 1 ? ` × ${row.quantity}` : ""}
                  </p>
                </div>
                <p className="order-row-price">
                  {formatPrice(row.unitPriceCents * row.quantity)}
                </p>
              </li>
            ))}
          </ul>

          <div className="price-line">
            <span className="price-value">{formatPrice(totalCents)}</span>
            <span className="price-note">
              Total · digital delivery, no tax in this demo
            </span>
          </div>

          <p className="notice">
            <Lock aria-hidden="true" /> Files are generated in your browser
            after checkout.
          </p>
        </aside>
      </div>
    </div>
  );
}
