import { Link } from "wouter";
import { ArrowUpRight, ArrowLeft } from "lucide-react";
import { Newsletter } from "@/components/MarketLayout";
import NotFound from "./NotFound";

const stories = [
  {
    slug: "the-art-of-looking",
    title: "The art of looking a little longer.",
    category: "ON SLOWING DOWN",
    image: "/manus-storage/kyoto-full_27ab7df6.jpg",
    excerpt:
      "A morning in the cedar mist, and a small reminder that the best things don't announce themselves.",
    body: [
      "There is a moment before the world wakes up when a place belongs only to itself. In Kyoto, that moment arrives with mist. It climbs the stone steps, moves between the cedar trunks, and makes the vermilion gates feel as though they have always been waiting for you.",
      "We were there to make a painting. We came home with a lesson in attention. A leaf, caught in the edge of a lantern. The exact shade of blue that lives between two mountain ridges. The quiet difference between looking at something and actually seeing it.",
      "A wallpaper is a small, ordinary thing. It's behind your work, behind your messages, behind the tabs you meant to close. But ordinary things are where life happens. We think they deserve a little care.",
      "So we keep the grain in the paper. We let the edges stay a little rough. We leave a whole expanse of sky where nothing needs to happen. These aren't photographs of the places we've been. They're reminders of how it felt to be there.",
      "Look a little longer. There's usually something worth finding.",
    ],
  },
  {
    slug: "a-colour-called-elsewhere",
    title: "A colour called elsewhere.",
    category: "FROM THE STUDIO",
    image: "/manus-storage/amalfi-full_fb8db0af.jpg",
    excerpt:
      "On ultramarine, afternoon light, and the palette we always seem to come home with.",
    body: [
      "Every place has a colour it keeps for itself. The Amalfi coast keeps a particular blue — not the pale blue of a postcard, but something deeper, almost mineral. At four in the afternoon, with the sun coming off the water, it makes the white walls look cream and the lemons look as though they have been painted twice.",
      "Ultramarine was once made from lapis lazuli. Its name means beyond the sea. We like that: a colour with a journey inside it.",
      "In the studio, we pair it with the colours it finds on the way. Terracotta. Meadow green. A warm, paper-coloured cream. The palette is small on purpose. It gives each landscape a little of the same feeling, like pages in a sketchbook kept over years.",
      "Colour is memory before it's anything else. This is our version of a place we would like to return to.",
    ],
  },
  {
    slug: "the-long-way-north",
    title: "Taking the long way north.",
    category: "FIELD NOTES",
    image: "/manus-storage/lofoten-full_b6b4b561.jpg",
    excerpt:
      "Red cabins, a light that wouldn't leave, and the beauty of having nowhere to hurry to.",
    body: [
      "The road to Lofoten keeps disappearing behind mountains. Every time you think you've arrived, there's another bridge, another inlet, another red cabin reflected in water so still it looks printed.",
      "In June, the light refuses to leave. Midnight is just another shade of afternoon. We sat on the shore with a sketchbook and waited for the mountains to change colour. They did. Slowly. And then they changed back.",
      "The finished artwork is quieter than the journey. That's how we wanted it. A small place to rest your eyes, with one warm window and a whole lot of blue.",
    ],
  },
];

export function Journal() {
  return (
    <main className="journal-page">
      <section className="page-intro">
        <p className="eyebrow">NOTES FROM ELSEWHERE</p>
        <h1>
          The <em>field notes.</em>
        </h1>
        <p>
          Places, colours, and things we noticed along the way.\nA small journal
          for the beautifully distracted.
        </p>
      </section>
      <section className="journal-grid">
        {stories.map((story, i) => (
          <Link
            href={`/journal/${story.slug}`}
            key={story.slug}
            className="journal-card"
          >
            <img src={story.image} alt={story.title} loading="lazy" />
            <div>
              <p className="eyebrow">
                FIELD NOTE 0{i + 1} · {story.category}
              </p>
              <h2>{story.title}</h2>
              <p>{story.excerpt}</p>
              <span className="line-link dark-link">
                Read the note <ArrowUpRight size={16} />
              </span>
            </div>
          </Link>
        ))}
      </section>
      <Newsletter />
    </main>
  );
}

export function Article({ slug }: { slug: string }) {
  const story = stories.find(s => s.slug === slug);
  if (!story) return <NotFound />;
  return (
    <main className="article-page">
      <div className="article-heading">
        <Link href="/journal" className="eyebrow">
          <ArrowLeft size={13} /> BACK TO THE JOURNAL
        </Link>
        <p className="eyebrow">{story.category} · A NOTE FROM THE ATELIER</p>
        <h1>{story.title}</h1>
        <p>{story.excerpt}</p>
      </div>
      <img className="article-image" src={story.image} alt={story.title} />
      <article className="article-body">
        {story.body.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
        <div className="article-signoff">
          Until next time,
          <br />
          <em>The Elsewhere Atelier</em>
        </div>
        <Link href="/shop" className="button button-blue">
          Find a view to keep <ArrowUpRight size={16} />
        </Link>
      </article>
      <Newsletter />
    </main>
  );
}

export function About() {
  return (
    <main className="about-page">
      <section className="about-intro">
        <p className="eyebrow">A SMALL ATELIER. A BIG WORLD.</p>
        <h1>
          We make places
          <br />
          <em>you can keep.</em>
        </h1>
        <p>
          For the days when you can't go far,
          <br />
          but your mind would like to.
        </p>
      </section>
      <img
        className="about-image"
        src="/manus-storage/highlands-full_61d73aca.jpg"
        alt="A painted Scottish landscape with a castle, heather and a winding road"
      />
      <section className="about-story">
        <p className="eyebrow">THE ELSEWHERE WAY</p>
        <div>
          <h2>
            Not every escape
            <br />
            needs a plane ticket.
          </h2>
          <p>
            Elsewhere is a collection of original illustrated landscapes, made
            for the screens we live with. We believe a little beauty in an
            ordinary place can change the feeling of a whole day.
          </p>
          <p>
            Our work borrows from the warmth of vintage travel prints: generous
            colour, visible grain, and landscapes that feel remembered rather
            than recorded. Every chapter is a different kind of elsewhere —
            mountain air, Mediterranean afternoons, cedar mist, desert light.
          </p>
          <p>
            Choose a place. Make it yours. Come back to it whenever you need a
            little room to breathe.
          </p>
          <Link href="/collections" className="line-link dark-link">
            Find your chapter <ArrowUpRight size={16} />
          </Link>
        </div>
      </section>
      <Newsletter />
    </main>
  );
}

const policies: Record<
  string,
  { title: string; intro: string; sections: { title: string; text: string }[] }
> = {
  licensing: {
    title: "A place to call your own.",
    intro:
      "Good art comes with a little clarity. Here's how you can use an Elsewhere wallpaper.",
    sections: [
      {
        title: "Personal licence",
        text: "Use your download on your own desktop, phone, tablet or display. You can keep it forever and use it on all the devices you personally own. A personal licence doesn't cover paid client work, advertising, merchandise, resale or redistribution of the artwork.",
      },
      {
        title: "Commercial licence",
        text: "Use the artwork in client presentations, digital campaigns, interiors and commercial screen displays with an audience of up to 500,000 views. One licence covers one end client or project. You may not sell the original file, include it in a stock library, claim authorship, or use it to train an AI model. Contact the atelier for larger or unusual projects.",
      },
      {
        title: "Formats and source artwork",
        text: "The original artwork is 2560 × 1440 pixels. Desktop 5K and 8K Ultra downloads are resized exports of that original; they are not native 5K or 8K illustrations. Mobile exports use a centre crop. The product preview lets you see the crop before choosing. Downloads are JPEG files.",
      },
      {
        title: "This is a demo marketplace",
        text: "The checkout is a demonstration: no money is charged, no card details are collected, and downloads are made available after completing the demo order. These licence descriptions explain the intended product experience and are not a paid commercial licence agreement.",
      },
    ],
  },
  faq: {
    title: "A few good questions.",
    intro: "The little details, answered without the small print.",
    sections: [
      {
        title: "Is this wallpaper for my wall or my screen?",
        text: "Your screen. Elsewhere sells illustrated digital wallpapers, not physical wall coverings. Choose desktop, mobile, or a large-screen format on the artwork page.",
      },
      {
        title: "How do downloads work?",
        text: "After the demo checkout, your order page includes a download button for each artwork. Your browser creates the selected JPEG export. Save your order link if you'd like to come back; the order is stored in the atelier's database.",
      },
      {
        title: "Can I preview it on my phone?",
        text: "Yes. Choose Mobile 4K on the artwork page to see a tall centre-cropped preview. The mobile export uses the same crop, so you can see what you're getting.",
      },
      {
        title: "Will I be charged?",
        text: "No. This is a demo storefront. The payment step is explicitly simulated and never asks for real payment information.",
      },
      {
        title: "Can I return a digital file?",
        text: "For this demo there are no charges to refund. A live storefront would need a separately configured payment provider and an agreed digital-goods refund policy.",
      },
      {
        title: "What if something isn't working?",
        text: "Try the download again in a current browser. Large 8K exports can take a few seconds and need more memory. You can always choose a smaller desktop export instead. For questions, use the Say hello link in the footer.",
      },
    ],
  },
  privacy: {
    title: "A little privacy, please.",
    intro: "We keep only what's needed to make the atelier work.",
    sections: [
      {
        title: "Information you share",
        text: "When you complete a demo order, we store your name, email, country, selected artworks and order total. Newsletter signup stores your email address. Billing address fields are used only in the checkout form and are not retained by our order database. We never collect card details.",
      },
      {
        title: "On your device",
        text: "Your shopping bag and saved artworks are stored in your browser's local storage. They remain on that browser until you remove them or clear site data. Your order link is the key to your order: keep it private.",
      },
      {
        title: "Newsletter",
        text: "Signing up adds your email address to the atelier's subscriber list. The demo does not automatically send email campaigns. Don't enter sensitive information or real payment details.",
      },
      {
        title: "Analytics and third-party services",
        text: "The site uses Manus-managed hosting, storage and analytics. Typefaces may load from Google Fonts. These providers may process standard request information such as IP address and browser type as part of serving the site.",
      },
      {
        title: "Questions or removal requests",
        text: "Contact the site owner through the configured contact channel if you want your newsletter or demo-order data removed. The email link displayed on this concept site is illustrative and should be replaced by the merchant's actual support address before launch.",
      },
    ],
  },
};
export function Policy({ slug }: { slug: string }) {
  const doc = policies[slug];
  if (!doc) return <NotFound />;
  return (
    <main className="policy-page">
      <div className="page-intro">
        <p className="eyebrow">THE LITTLE DETAILS</p>
        <h1>{doc.title}</h1>
        <p>{doc.intro}</p>
      </div>
      <div className="policy-content">
        {doc.sections.map(section => (
          <section key={section.title}>
            <h2>{section.title}</h2>
            <p>{section.text}</p>
          </section>
        ))}
        <Link href="/shop" className="line-link dark-link">
          Back to the wallpapers <ArrowUpRight size={16} />
        </Link>
      </div>
    </main>
  );
}
