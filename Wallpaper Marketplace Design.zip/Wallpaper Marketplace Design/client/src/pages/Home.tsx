import { useEffect, useState } from "react";
import { Link } from "wouter";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Monitor,
  Sparkles,
  Download,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import ArtCard from "@/components/ArtCard";
import { ErrorState, Newsletter } from "@/components/MarketLayout";

const fallbackSlides = [
  {
    image: "/manus-storage/alpine-full_92c07a49.jpg",
    location: "SWITZERLAND",
    coordinates: "46°33′ N · 06°48′ E",
    collection: "THE ALPINE CHAPTER",
    chapter: "alpine",
    slug: "vaud-no-01",
    name: "Vaud, No. 01",
  },
  {
    image: "/manus-storage/amalfi-full_fb8db0af.jpg",
    location: "ITALY",
    coordinates: "40°38′ N · 14°36′ E",
    collection: "THE MIDDLE SEA",
    chapter: "mediterranean",
    slug: "amalfi-no-02",
    name: "Amalfi, No. 02",
  },
  {
    image: "/manus-storage/kyoto-full_27ab7df6.jpg",
    location: "JAPAN",
    coordinates: "35°00′ N · 135°46′ E",
    collection: "THE QUIET EAST",
    chapter: "east",
    slug: "kyoto-no-03",
    name: "Kyoto, No. 03",
  },
  {
    image: "/manus-storage/sahara-full_2df7858c.jpg",
    location: "MOROCCO",
    coordinates: "31°09′ N · 03°58′ W",
    collection: "WARM LATITUDES",
    chapter: "south",
    slug: "sahara-no-04",
    name: "Sahara, No. 04",
  },
];

export default function Home() {
  const [slide, setSlide] = useState(0);
  const query = trpc.catalog.featured.useQuery();
  const data = query.data;
  const slides = data?.wallpapers.length
    ? data.wallpapers.slice(0, 4).map(art => ({
        image: art.image,
        location: (
          art.location?.split(", ").pop() || "ELSEWHERE"
        ).toUpperCase(),
        coordinates: art.coordinates || "",
        collection: (art.collectionName || "THE ATELIER EDIT").toUpperCase(),
        chapter: art.collectionSlug || "alpine",
        slug: art.slug,
        name: art.title,
      }))
    : fallbackSlides;
  const active = slides[slide % slides.length];
  const move = (delta: number) =>
    setSlide(current => (current + delta + slides.length) % slides.length);
  useEffect(() => {
    const reduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    if (reduced) return;
    const timer = window.setTimeout(
      () => setSlide(current => (current + 1) % slides.length),
      12000
    );
    return () => window.clearTimeout(timer);
  }, [slide, slides.length]);
  return (
    <main>
      <section className="hero" aria-label="Featured wallpaper destinations">
        <div className="hero-art">
          {slides.map((item, i) => (
            <img
              key={item.slug}
              className={i === slide ? "active" : ""}
              src={item.image}
              alt={`Vintage illustrated landscape of ${item.location.toLowerCase()}`}
              fetchPriority={i === 0 ? "high" : "auto"}
            />
          ))}
        </div>
        <div className={`hero-shade ${slide === 2 ? "extra-shade" : ""}`} />
        <div className="hero-copy">
          <p className="eyebrow">A DIFFERENT KIND OF WALLPAPER</p>
          <h1>
            Get Lost.
            <br />
            Feel Found.
          </h1>
          <p className="hero-description">
            For the places you'd rather be.
            <br />
            Artful wallpapers for a little everyday escape.
          </p>
          <div className="hero-ctas">
            <Link href="/shop" className="button button-cream">
              Find your elsewhere <ArrowUpRight size={17} />
            </Link>
            <Link href={`/collection/${active.chapter}`} className="line-link">
              Explore the collection <ArrowRight size={17} />
            </Link>
          </div>
        </div>
        <div className="hero-bottom">
          <Link href={`/wallpaper/${active.slug}`} className="hero-place">
            <MapPin size={24} fill="currentColor" strokeWidth={0} />
            <span>
              {active.location}
              <br />
              {active.coordinates}
            </span>
          </Link>
          <Link
            href={`/collection/${active.chapter}`}
            className="hero-collection"
          >
            {active.collection.split(" ").slice(0, 2).join(" ")}
            <br />
            {active.collection.split(" ").slice(2).join(" ")}
          </Link>
          <a href="#discover" className="hero-scroll">
            SCROLL TO WANDER <ArrowDown size={14} />
          </a>
          <div className="slide-controls">
            <span className="slide-counter">
              {String(slide + 1).padStart(2, "0")}{" "}
              <span>/ {String(slides.length).padStart(2, "0")}</span>
            </span>
            <button
              aria-label="Previous featured wallpaper"
              onClick={() => move(-1)}
            >
              <ChevronLeft size={19} />
            </button>
            <span className="control-divider" />
            <button
              aria-label="Next featured wallpaper"
              onClick={() => move(1)}
            >
              <ChevronRight size={19} />
            </button>
          </div>
        </div>
        <div className="hero-progress" key={slide} />
      </section>

      <section className="intro-section" id="discover">
        <div className="intro-label">
          <span className="tiny-star">
            <Sparkles size={35} strokeWidth={1} />
          </span>
          <p className="eyebrow">
            OPEN A WINDOW.
            <br />
            NOT ANOTHER TAB.
          </p>
        </div>
        <div className="intro-main">
          <h2>
            A view worth
            <br />
            <em>getting lost in.</em>
          </h2>
          <div className="intro-copy">
            <p>
              Your screen is a place you spend a lot of time.
              <br />
              Make it somewhere you love.
            </p>
            <p>
              Original illustrated landscapes. Thoughtfully coloured.
              <br />
              Made to take you a little further from the everyday.
            </p>
            <Link href="/about" className="line-link dark-link">
              Meet the atelier <ArrowUpRight size={15} />
            </Link>
          </div>
        </div>
      </section>

      <section className="featured-section">
        <div className="section-heading">
          <div>
            <p className="eyebrow">THE PLACES WE KEEP COMING BACK TO</p>
            <h2>Somewhere for you.</h2>
          </div>
          <Link href="/shop" className="line-link dark-link">
            Explore all wallpapers <ArrowUpRight size={16} />
          </Link>
        </div>
        {query.isLoading ? (
          <div
            className="art-grid featured-grid"
            aria-label="Loading featured artworks"
          >
            {[0, 1, 2].map(i => (
              <div key={i} className="art-skeleton" />
            ))}
          </div>
        ) : query.isError ? (
          <ErrorState retry={() => query.refetch()} />
        ) : data?.wallpapers.length ? (
          <div className="art-grid featured-grid">
            {data.wallpapers.slice(0, 3).map((art, i) => (
              <ArtCard key={art.id} art={art} number={i + 1} />
            ))}
          </div>
        ) : (
          <p className="lead">
            The next view is on its way. Explore the collections in the
            meantime.
          </p>
        )}
        <div className="fine-caption">
          <span>ORIGINAL ARTWORK · INSTANT DIGITAL DOWNLOADS</span>
          <span>THE ATELIER EDIT</span>
        </div>
      </section>

      <section className="chapter-feature">
        <div className="chapter-image">
          <img
            src="/manus-storage/amalfi-full_fb8db0af.jpg"
            alt="Illustrated Amalfi village overlooking the sea"
            loading="lazy"
          />
          <span className="image-caption">
            <MapPin size={14} /> 40°38′ N · 14°36′ E
          </span>
        </div>
        <div className="chapter-copy">
          <p className="eyebrow">CHAPTER 02 — THE MIDDLE SEA</p>
          <h2>
            A slower
            <br />
            kind of
            <br />
            <em>summer.</em>
          </h2>
          <p>
            Salt on the shutters. Lemons in the shade.
            <br />A little piece of the Mediterranean,
            <br />
            wherever you happen to be.
          </p>
          <Link
            href="/collection/mediterranean"
            className="button button-cream"
          >
            Wander the collection <ArrowUpRight size={16} />
          </Link>
          <span className="chapter-footnote">
            TWO PLACES. ONE ENDLESS AFTERNOON.
          </span>
        </div>
      </section>

      <section className="benefits">
        <div className="benefit">
          <Sparkles size={25} strokeWidth={1} />
          <div>
            <h3>Art, not an algorithm.</h3>
            <p>Original landscapes with a human point of view.</p>
          </div>
        </div>
        <div className="benefit">
          <Monitor size={25} strokeWidth={1} />
          <div>
            <h3>Made for your screen.</h3>
            <p>Desktop, mobile, and beautifully big displays.</p>
          </div>
        </div>
        <div className="benefit">
          <Download size={25} strokeWidth={1} />
          <div>
            <h3>A place. In an instant.</h3>
            <p>Choose your view. Download. Drift a little.</p>
          </div>
        </div>
      </section>

      <section className="journal-preview">
        <div className="section-heading">
          <div>
            <p className="eyebrow">NOTES FROM ELSEWHERE</p>
            <h2>A little off the beaten path.</h2>
          </div>
          <Link href="/journal" className="line-link dark-link">
            Open the journal <ArrowUpRight size={16} />
          </Link>
        </div>
        <Link
          href="/journal/the-art-of-looking"
          className="journal-feature-link"
        >
          <img
            src="/manus-storage/kyoto-card_4306ce7f.jpg"
            alt="Cedar forest and vermilion gates in Japanese morning mist"
            loading="lazy"
          />
          <div>
            <p className="eyebrow">FIELD NOTE 01 · 5 MIN READ</p>
            <h3>
              The art of
              <br />
              <em>looking a little longer.</em>
            </h3>
            <p>
              On slowing down, seeing more, and the places
              <br />
              that stay with you long after you leave.
            </p>
            <span className="line-link dark-link">
              Read the story <ArrowUpRight size={16} />
            </span>
          </div>
        </Link>
      </section>
      <Newsletter />
    </main>
  );
}
