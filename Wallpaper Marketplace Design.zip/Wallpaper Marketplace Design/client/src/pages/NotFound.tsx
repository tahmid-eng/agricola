import { useEffect } from "react";
import { Link } from "wouter";
import { ArrowUpRight, Compass } from "lucide-react";

export default function NotFound() {
  useEffect(() => {
    const robots = document.createElement("meta");
    robots.name = "robots";
    robots.content = "noindex";
    document.head.appendChild(robots);
    document.title = "Off the Map — Elsewhere Atelier";
    // A full request preserves the server's real 404 status.
    if (window.location.pathname.replace(/\/$/, "") !== "/404") {
      window.location.replace("/404");
    }
    return () => robots.remove();
  }, []);
  return (
    <main
      className="page-state"
      style={{ minHeight: "80vh", textAlign: "center" }}
    >
      <Compass size={40} strokeWidth={1} color="#10269e" />
      <p className="eyebrow">404 — A LITTLE OFF THE MAP</p>
      <h1 style={{ fontSize: "clamp(48px,6vw,80px)" }}>
        Not all who wander
        <br />
        <em>find this page.</em>
      </h1>
      <p>That place isn't in our archive. There's plenty more to discover.</p>
      <Link href="/shop" className="button button-blue">
        Find your elsewhere <ArrowUpRight size={16} />
      </Link>
    </main>
  );
}
