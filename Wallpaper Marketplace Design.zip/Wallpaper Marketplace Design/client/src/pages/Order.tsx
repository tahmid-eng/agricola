import NotFound from "@/pages/NotFound";
import { trpc } from "@/lib/trpc";
import type { ResolutionId } from "@/lib/types";
import { formatPrice, licenseById, resolutionById } from "@shared/market";
import {
  AlertCircle,
  ArrowLeft,
  Check,
  Download,
  Info,
  Loader2,
  Mail,
  MapPin,
  RefreshCw,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";

/** The artwork master really is 2560 × 1440; every export is an upscale of it. */
const SOURCE_WIDTH = 2560;
const SOURCE_HEIGHT = 1440;

const EXPORT_SIZES: Record<ResolutionId, { width: number; height: number }> = {
  desktop: { width: 5120, height: 2880 },
  mobile: { width: 1440, height: 3120 },
  "8k": { width: 7680, height: 4320 },
};

type ReceiptSnapshot = {
  reference?: string;
  placedAt?: string;
  customer?: { name?: string; email?: string; country?: string };
  billing?: { address?: string; city?: string; postalCode?: string };
  totalCents?: number;
};

type ExportableItem = {
  id: number;
  slug: string | null;
  title: string | null;
  image: string | null;
  resolution: string;
  license: string;
};

function isNotFound(error: unknown) {
  const code = (error as { data?: { code?: string } } | null)?.data?.code;
  return code === "NOT_FOUND";
}

function exportSize(resolution: string) {
  return EXPORT_SIZES[resolution as ResolutionId] ?? EXPORT_SIZES.desktop;
}

function formatDate(value: Date | string | null | undefined) {
  if (!value) return "—";
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "long",
    timeStyle: "short",
  }).format(date);
}

function readSnapshot(reference: string): ReceiptSnapshot | null {
  try {
    const raw =
      sessionStorage.getItem(`elsewhere-order-${reference}`) ??
      sessionStorage.getItem(`elsewhere-order-${reference.toUpperCase()}`);
    return raw ? (JSON.parse(raw) as ReceiptSnapshot) : null;
  } catch {
    return null;
  }
}

function safeFileName(item: ExportableItem, resolution: string) {
  const base = (item.slug ?? item.title ?? "elsewhere-artwork")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return `elsewhere-${base || "artwork"}-${resolution}.jpg`;
}

async function decodeSource(url: string): Promise<{
  source: CanvasImageSource;
  width: number;
  height: number;
  release: () => void;
}> {
  const response = await fetch(url, {
    mode: "cors",
    credentials: "same-origin",
  });
  if (!response.ok) {
    throw new Error(
      `The artwork file couldn't be fetched (HTTP ${response.status}).`
    );
  }
  const blob = await response.blob();
  if (blob.size === 0) {
    throw new Error("The artwork file came back empty.");
  }

  if (typeof createImageBitmap === "function") {
    try {
      const bitmap = await createImageBitmap(blob);
      return {
        source: bitmap,
        width: bitmap.width,
        height: bitmap.height,
        release: () => bitmap.close(),
      };
    } catch {
      // Fall through to an <img> decode; some browsers refuse certain JPEGs here.
    }
  }

  const objectUrl = URL.createObjectURL(blob);
  const image = new Image();
  image.src = objectUrl;
  try {
    await image.decode();
  } catch {
    URL.revokeObjectURL(objectUrl);
    throw new Error("This artwork couldn't be decoded by your browser.");
  }
  return {
    source: image,
    width: image.naturalWidth,
    height: image.naturalHeight,
    release: () => URL.revokeObjectURL(objectUrl),
  };
}

function triggerDownload(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  anchor.rel = "noopener";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  // Give the browser time to start the save before the URL disappears.
  window.setTimeout(() => URL.revokeObjectURL(url), 20_000);
}

async function exportArtwork(item: ExportableItem) {
  if (!item.image) {
    throw new Error(
      "This artwork has no image on record, so there's nothing to export."
    );
  }
  const target = exportSize(item.resolution);
  const { source, width, height, release } = await decodeSource(item.image);

  try {
    const canvas = document.createElement("canvas");
    canvas.width = target.width;
    canvas.height = target.height;
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) {
      throw new Error(
        "Your browser couldn't open a drawing surface for this export."
      );
    }

    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
    context.fillStyle = "#101322";
    context.fillRect(0, 0, target.width, target.height);

    // Cover crop: portrait targets take a centred slice, landscape targets use the full frame.
    const scale = Math.max(target.width / width, target.height / height);
    const cropWidth = Math.min(width, target.width / scale);
    const cropHeight = Math.min(height, target.height / scale);
    const sourceX = (width - cropWidth) / 2;
    const sourceY = (height - cropHeight) / 2;

    context.drawImage(
      source,
      sourceX,
      sourceY,
      cropWidth,
      cropHeight,
      0,
      0,
      target.width,
      target.height
    );

    const blob = await new Promise<Blob | null>(resolve => {
      canvas.toBlob(resolve, "image/jpeg", 0.92);
    });
    if (!blob) {
      throw new Error(
        "The JPEG couldn't be encoded — this device may be out of memory."
      );
    }

    triggerDownload(blob, safeFileName(item, item.resolution));

    // Release the large canvas backing store before the next export.
    canvas.width = 1;
    canvas.height = 1;
  } finally {
    release();
  }
}

export default function Order({ reference }: { reference: string }) {
  const query = trpc.orders.get.useQuery(
    { reference: reference ?? "" },
    { enabled: Boolean(reference && reference.length >= 4), retry: false }
  );
  const snapshot = useMemo(
    () => (reference ? readSnapshot(reference) : null),
    [reference]
  );

  const [pendingItemId, setPendingItemId] = useState<number | null>(null);
  const [exportErrors, setExportErrors] = useState<Record<number, string>>({});
  const [started, setStarted] = useState<Record<number, boolean>>({});

  if (!reference || reference.length < 4) {
    return (
      <div className="commerce-page">
        <div className="notice notice-error" role="alert">
          <AlertCircle aria-hidden="true" />
          <p>
            That order link is missing its reference. Check your saved order
            link and try again.
          </p>
        </div>
        <div className="button-row">
          <Link href="/" className="button button-outline">
            <ArrowLeft aria-hidden="true" /> Back to Elsewhere
          </Link>
        </div>
      </div>
    );
  }

  if (query.isLoading) {
    return (
      <div className="commerce-page" aria-busy="true">
        <p className="notice">
          <Loader2 className="icon-spin" aria-hidden="true" /> Looking up order{" "}
          {reference}…
        </p>
      </div>
    );
  }

  if (query.error && isNotFound(query.error)) {
    return <NotFound />;
  }

  if (query.error || !query.data) {
    return (
      <div className="commerce-page">
        <div className="notice notice-error" role="alert">
          <AlertCircle aria-hidden="true" />
          <p>{query.error?.message ?? "We couldn't load that order."}</p>
        </div>
        <div className="button-row">
          <button
            type="button"
            className="button button-blue"
            onClick={() => query.refetch()}
          >
            <RefreshCw aria-hidden="true" /> Try again
          </button>
          <Link href="/" className="button button-outline">
            <ArrowLeft aria-hidden="true" /> Back to Elsewhere
          </Link>
        </div>
      </div>
    );
  }

  const { order, items } = query.data;
  const busy = pendingItemId !== null;

  const handleDownload = async (item: ExportableItem) => {
    if (busy) return;
    setPendingItemId(item.id);
    setExportErrors(current => {
      const next = { ...current };
      delete next[item.id];
      return next;
    });
    setStarted(current => ({ ...current, [item.id]: false }));
    try {
      await exportArtwork(item);
      setStarted(current => ({ ...current, [item.id]: true }));
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "That download didn't start. Please try again.";
      setExportErrors(current => ({ ...current, [item.id]: message }));
    } finally {
      setPendingItemId(null);
    }
  };

  return (
    <div className="commerce-page order-page">
      <header className="order-head">
        <p className="eyebrow">Receipt · {order.reference}</p>
        <h1 className="display-title">The place is yours</h1>
        <p className="lead">
          Thank you, {order.name}. Your order is on record — files are generated
          in your browser the moment you ask for them.
        </p>
        <p className="status-pill">
          <Check aria-hidden="true" />{" "}
          {order.status === "paid" ? "Paid (demo)" : order.status}
        </p>
      </header>

      <div className="checkout-layout">
        <div className="checkout-main">
          <section aria-labelledby="downloads-heading">
            <h2 id="downloads-heading" className="section-heading">
              Your downloads
            </h2>

            <p className="notice" role="note">
              <Info aria-hidden="true" />
              Every file is rendered on the fly from the same {
                SOURCE_WIDTH
              } × {SOURCE_HEIGHT} master. Desktop 5K, Mobile 4K and 8K downloads
              are upscaled, not natively drawn — a real 8K original doesn&apos;t
              exist yet, and we won&apos;t pretend otherwise.
            </p>

            {items.length === 0 ? (
              <p className="notice notice-error" role="alert">
                <AlertCircle aria-hidden="true" /> This order has no items on
                record. Keep your order reference and contact the site owner.
              </p>
            ) : (
              <ul className="download-list">
                {items.map(item => {
                  const size = exportSize(item.resolution);
                  const isPending = pendingItemId === item.id;
                  const error = exportErrors[item.id];
                  const isStarted = started[item.id];
                  const title = item.title ?? "Artwork";
                  return (
                    <li key={item.id} className="download-row">
                      <div className="download-preview">
                        {(item.thumb ?? item.image) ? (
                          <img
                            src={item.thumb ?? item.image ?? ""}
                            alt={`${title} thumbnail`}
                            width={192}
                            height={108}
                            loading="lazy"
                          />
                        ) : (
                          <span
                            className="download-preview-empty"
                            aria-hidden="true"
                          />
                        )}
                      </div>

                      <div className="download-body">
                        <h3 className="download-title">
                          {item.slug ? (
                            <Link href={`/wallpaper/${item.slug}`}>
                              {title}
                            </Link>
                          ) : (
                            title
                          )}
                        </h3>
                        <p className="download-meta">
                          {resolutionById(item.resolution).label} · {size.width}{" "}
                          × {size.height} · {licenseById(item.license).label}{" "}
                          licence
                          {item.quantity > 1 ? ` × ${item.quantity}` : ""}
                        </p>
                        {item.location ? (
                          <p className="download-meta">
                            <MapPin aria-hidden="true" /> {item.location}
                          </p>
                        ) : null}
                        <p className="download-note">
                          Upscaled from original {SOURCE_WIDTH}×{SOURCE_HEIGHT}{" "}
                          artwork.
                        </p>

                        {error ? (
                          <p className="notice notice-error" role="alert">
                            <AlertCircle aria-hidden="true" /> {error}
                          </p>
                        ) : null}
                        <p
                          className="live-region"
                          role="status"
                          aria-live="polite"
                        >
                          {isStarted && !isPending
                            ? `Download started: ${size.width} × ${size.height} JPEG.`
                            : ""}
                        </p>
                      </div>

                      <div className="download-actions">
                        <p className="download-price">
                          {formatPrice(item.unitPriceCents * item.quantity)}
                        </p>
                        <button
                          type="button"
                          className="button button-blue"
                          onClick={() => handleDownload(item)}
                          disabled={busy}
                          aria-busy={isPending}
                          aria-label={`Download ${title} at ${size.width} by ${size.height} pixels`}
                        >
                          {isPending ? (
                            <>
                              <Loader2
                                className="icon-spin"
                                aria-hidden="true"
                              />{" "}
                              Preparing…
                            </>
                          ) : (
                            <>
                              <Download aria-hidden="true" /> Download JPEG
                            </>
                          )}
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}

            <p className="export-caveat">
              Exports are produced locally by your browser, so the 8K file needs
              a device with enough memory to hold a 7680 × 4320 canvas. If it
              fails, the Desktop 5K file is the safer choice.
            </p>
          </section>
        </div>

        <aside className="order-summary" aria-labelledby="receipt-heading">
          <h2 id="receipt-heading" className="section-heading">
            Order summary
          </h2>

          <dl className="detail-list">
            <div className="detail-row">
              <dt>Reference</dt>
              <dd>{order.reference}</dd>
            </div>
            <div className="detail-row">
              <dt>Placed</dt>
              <dd>{formatDate(order.createdAt ?? snapshot?.placedAt)}</dd>
            </div>
            <div className="detail-row">
              <dt>Name</dt>
              <dd>{order.name}</dd>
            </div>
            <div className="detail-row">
              <dt>Email</dt>
              <dd>{order.email}</dd>
            </div>
            {order.country ? (
              <div className="detail-row">
                <dt>Country</dt>
                <dd>{order.country}</dd>
              </div>
            ) : null}
            {snapshot?.billing?.city || snapshot?.billing?.postalCode ? (
              <div className="detail-row">
                <dt>Billing</dt>
                <dd>
                  {[
                    snapshot.billing.address,
                    snapshot.billing.city,
                    snapshot.billing.postalCode,
                  ]
                    .filter(Boolean)
                    .join(", ")}
                </dd>
              </div>
            ) : null}
          </dl>

          <div className="price-line">
            <span className="price-value">{formatPrice(order.totalCents)}</span>
            <span className="price-note">
              Total · demo payment, no money was charged
            </span>
          </div>

          <p className="notice">
            <Mail aria-hidden="true" /> Keep this page bookmarked — it is your
            download link for this order.
          </p>

          <div className="button-row">
            <Link href="/" className="button button-outline">
              <ArrowLeft aria-hidden="true" /> Keep browsing
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
