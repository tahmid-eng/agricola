import NotFound from "@/pages/NotFound";
import { trpc } from "@/lib/trpc";
import { useMarket } from "@/contexts/MarketContext";
import type { LicenceId, ResolutionId, Wallpaper } from "@/lib/types";
import {
  LICENSES,
  RESOLUTIONS,
  computeUnitPriceCents,
  formatPrice,
  licenseById,
  resolutionById,
} from "@shared/market";
import {
  AlertCircle,
  ArrowLeft,
  Check,
  Image as ImageIcon,
  Loader2,
  Lock,
  MapPin,
  Maximize2,
  ShieldCheck,
  X,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "wouter";

/** The only master that actually exists for every artwork right now. */
const SOURCE_WIDTH = 2560;
const SOURCE_HEIGHT = 1440;

function isNotFound(error: unknown) {
  const code = (error as { data?: { code?: string } } | null)?.data?.code;
  return code === "NOT_FOUND";
}

function splitPalettes(raw: string | null | undefined) {
  if (!raw) return [];
  return raw
    .split(",")
    .map(value => value.trim())
    .filter(Boolean);
}

function PaletteDots({ palettes }: { palettes: string[] }) {
  if (palettes.length === 0) return null;
  const swatches: Record<string, string> = {
    ultramarine: "#12249B",
    terracotta: "#C9612A",
    sage: "#7C8B5A",
    ochre: "#D9A43C",
    rose: "#D98A7A",
    ink: "#101322",
  };
  return (
    <ul className="palette-row" aria-label="Palette used in this artwork">
      {palettes.map(id => (
        <li key={id} className="palette-dot" title={id}>
          <span
            aria-hidden="true"
            className="palette-swatch"
            style={{ backgroundColor: swatches[id] ?? "#12249B" }}
          />
          <span className="palette-label">{id}</span>
        </li>
      ))}
    </ul>
  );
}

function RelatedCard({ wallpaper }: { wallpaper: Wallpaper }) {
  const preview = wallpaper.thumb ?? wallpaper.image;
  return (
    <Link href={`/wallpaper/${wallpaper.slug}`} className="art-card">
      <div className="art-card-media">
        <img
          src={preview}
          alt={`${wallpaper.title}, ${wallpaper.collectionName ?? "Elsewhere"} wallpaper preview`}
          loading="lazy"
          width={640}
          height={360}
        />
      </div>
      <div className="art-card-body">
        <p className="eyebrow">{wallpaper.collectionName ?? "Elsewhere"}</p>
        <h3 className="art-card-title">{wallpaper.title}</h3>
        {wallpaper.location ? (
          <p className="art-card-meta">{wallpaper.location}</p>
        ) : null}
        <p className="art-card-price">
          from {formatPrice(wallpaper.basePriceCents)}
        </p>
      </div>
    </Link>
  );
}

export default function Product({ slug }: { slug: string }) {
  const { addToCart } = useMarket();
  const [resolution, setResolution] = useState<ResolutionId>("desktop");
  const [license, setLicense] = useState<LicenceId>("personal");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [added, setAdded] = useState(false);
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const addedTimer = useRef<number | null>(null);

  const query = trpc.catalog.wallpaper.useQuery({ slug }, { retry: false });

  const closePreview = useCallback(() => {
    setPreviewOpen(false);
    triggerRef.current?.focus();
  }, []);

  useEffect(() => {
    if (!previewOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        closePreview();
      }
      if (event.key === "Tab") {
        // The close control is the only focusable element in the overlay.
        event.preventDefault();
        closeRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [previewOpen, closePreview]);

  useEffect(() => {
    setResolution("desktop");
    setLicense("personal");
    setAdded(false);
    if (addedTimer.current) window.clearTimeout(addedTimer.current);
  }, [slug]);

  useEffect(() => {
    return () => {
      if (addedTimer.current) window.clearTimeout(addedTimer.current);
    };
  }, []);

  if (query.isLoading) {
    return (
      <div className="commerce-page" aria-busy="true" aria-live="polite">
        <p className="notice">
          <Loader2 className="icon-spin" aria-hidden="true" /> Fetching this
          artwork…
        </p>
      </div>
    );
  }

  if (query.error && isNotFound(query.error)) {
    return <NotFound />;
  }

  if (query.error || !query.data) {
    return (
      <div className="commerce-page">
        <div className="notice notice-error" role="alert">
          <AlertCircle aria-hidden="true" />
          <p>
            {query.error?.message ?? "This artwork could not be loaded."} The
            preview server may be resting — try again in a moment.
          </p>
        </div>
        <div className="button-row">
          <button
            type="button"
            className="button button-blue"
            onClick={() => query.refetch()}
          >
            Try again
          </button>
          <Link href="/" className="button button-outline">
            <ArrowLeft aria-hidden="true" /> Back to Elsewhere
          </Link>
        </div>
      </div>
    );
  }

  const { wallpaper, related } = query.data;
  const chosenResolution = resolutionById(resolution);
  const chosenLicense = licenseById(license);
  const unitPriceCents = computeUnitPriceCents(
    wallpaper.basePriceCents,
    resolution,
    license
  );
  const palettes = splitPalettes(wallpaper.palettes);
  const oversized = true;

  const handleAddToCart = () => {
    addToCart({
      slug: wallpaper.slug,
      title: wallpaper.title,
      image: wallpaper.image,
      thumb: wallpaper.thumb,
      location: wallpaper.location,
      collectionName: wallpaper.collectionName,
      basePriceCents: wallpaper.basePriceCents,
      resolution,
      license,
    });
    setAdded(true);
    if (addedTimer.current) window.clearTimeout(addedTimer.current);
    addedTimer.current = window.setTimeout(() => setAdded(false), 3000);
  };

  return (
    <div className="commerce-page product-page">
      <nav className="breadcrumb" aria-label="Breadcrumb">
        <ol>
          <li>
            <Link href="/">Elsewhere</Link>
          </li>
          <li aria-hidden="true">/</li>
          <li>
            {wallpaper.collectionSlug ? (
              <Link href={`/collection/${wallpaper.collectionSlug}`}>
                {wallpaper.collectionName ?? wallpaper.collectionSlug}
              </Link>
            ) : (
              <span>{wallpaper.collectionName ?? "The archive"}</span>
            )}
          </li>
          <li aria-hidden="true">/</li>
          <li aria-current="page">{wallpaper.title}</li>
        </ol>
      </nav>

      <div className="product-layout">
        <div className="product-visual">
          <button
            ref={triggerRef}
            type="button"
            className={`preview-trigger ${resolution === "mobile" ? "mobile-preview" : ""}`}
            onClick={() => setPreviewOpen(true)}
            aria-label={`Open full-screen preview of ${wallpaper.title}`}
          >
            <img
              src={wallpaper.image}
              alt={`${wallpaper.title}${
                wallpaper.location ? `, ${wallpaper.location}` : ""
              } — illustrated wallpaper artwork`}
              width={SOURCE_WIDTH}
              height={SOURCE_HEIGHT}
              fetchPriority="high"
            />
            <span className="preview-hint">
              <Maximize2 aria-hidden="true" /> Full screen
            </span>
          </button>

          <p className="source-note">
            <ImageIcon aria-hidden="true" />
            Original artwork: {SOURCE_WIDTH} × {SOURCE_HEIGHT}. Larger exports
            are resized; mobile is centre-cropped.
          </p>
        </div>

        <div className="product-info">
          <p className="eyebrow">
            {wallpaper.collectionChapter
              ? `${wallpaper.collectionChapter} · `
              : ""}
            {wallpaper.collectionName ?? "Elsewhere"}
          </p>
          <h1 className="display-title">{wallpaper.title}</h1>
          {wallpaper.subtitle ? (
            <p className="lead">{wallpaper.subtitle}</p>
          ) : null}

          <p className="product-location">
            <MapPin aria-hidden="true" />
            <span>{wallpaper.location ?? "A place we keep to ourselves"}</span>
            {wallpaper.coordinates ? (
              <span className="coordinates">{wallpaper.coordinates}</span>
            ) : null}
          </p>

          {wallpaper.description ? (
            <p className="product-description">{wallpaper.description}</p>
          ) : null}

          <PaletteDots palettes={palettes} />

          <fieldset className="option-fieldset">
            <legend className="section-heading">Choose your resolution</legend>
            <div className="option-grid" role="group" aria-label="Resolution">
              {RESOLUTIONS.map(option => {
                const selected = option.id === resolution;
                return (
                  <button
                    key={option.id}
                    type="button"
                    className={`option-button${selected ? " selected" : ""}`}
                    onClick={() => setResolution(option.id)}
                    aria-pressed={selected}
                  >
                    <span className="option-label">{option.label}</span>
                    <span className="option-pixels">{option.pixels}</span>
                    <span className="option-note">{option.note}</span>
                    {selected ? (
                      <Check className="option-check" aria-hidden="true" />
                    ) : null}
                  </button>
                );
              })}
            </div>
            {oversized ? (
              <p className="option-caveat">
                {chosenResolution.label} files are upscaled from the{" "}
                {SOURCE_WIDTH} × {SOURCE_HEIGHT} master.
              </p>
            ) : null}
          </fieldset>

          <fieldset className="option-fieldset">
            <legend className="section-heading">Choose your licence</legend>
            <div
              className="option-grid option-grid-licences"
              role="group"
              aria-label="Licence"
            >
              {LICENSES.map(option => {
                const selected = option.id === license;
                return (
                  <button
                    key={option.id}
                    type="button"
                    className={`option-button${selected ? " selected" : ""}`}
                    onClick={() => setLicense(option.id)}
                    aria-pressed={selected}
                  >
                    <span className="option-label">{option.label}</span>
                    <span className="option-note">{option.blurb}</span>
                    {selected ? (
                      <Check className="option-check" aria-hidden="true" />
                    ) : null}
                  </button>
                );
              })}
            </div>
          </fieldset>

          <div className="price-line">
            <span className="price-value">{formatPrice(unitPriceCents)}</span>
            <span className="price-note">
              {chosenResolution.label} · {chosenLicense.label} licence · demo
              pricing — no charge
            </span>
          </div>

          <div className="button-row">
            <button
              type="button"
              className="button button-blue"
              onClick={handleAddToCart}
            >
              <Lock aria-hidden="true" /> Add to cart —{" "}
              {formatPrice(unitPriceCents)}
            </button>
            <button
              type="button"
              className="button button-outline"
              onClick={() => setPreviewOpen(true)}
            >
              <Maximize2 aria-hidden="true" /> Preview
            </button>
          </div>
          <p className="live-region" role="status" aria-live="polite">
            {added ? `${wallpaper.title} added to your cart.` : ""}
          </p>

          <dl className="detail-list">
            <div className="detail-row">
              <dt>Resolution</dt>
              <dd>{chosenResolution.pixels}</dd>
            </div>
            <div className="detail-row">
              <dt>Licence</dt>
              <dd>{chosenLicense.label}</dd>
            </div>
            <div className="detail-row">
              <dt>Format</dt>
              <dd>JPEG, generated in your browser at download</dd>
            </div>
            <div className="detail-row">
              <dt>Delivery</dt>
              <dd>Instant download after checkout</dd>
            </div>
          </dl>

          <p className="licence-note">
            <ShieldCheck aria-hidden="true" />
            {chosenLicense.blurb} Prints, resale and redistribution need a
            separate arrangement — write to us.
          </p>
        </div>
      </div>

      {related.length > 0 ? (
        <section className="related-section" aria-labelledby="related-heading">
          <div className="section-head">
            <h2 id="related-heading" className="section-heading">
              More from {wallpaper.collectionName ?? "the archive"}
            </h2>
            {wallpaper.collectionSlug ? (
              <Link
                href={`/collection/${wallpaper.collectionSlug}`}
                className="text-link"
              >
                View the chapter
              </Link>
            ) : null}
          </div>
          <div className="art-grid">
            {related.map(item => (
              <RelatedCard key={item.id} wallpaper={item} />
            ))}
          </div>
        </section>
      ) : null}

      {previewOpen ? (
        <div
          className="preview-dialog"
          role="dialog"
          aria-modal="true"
          aria-label={`${wallpaper.title} preview`}
        >
          <button
            ref={closeRef}
            type="button"
            className="preview-close"
            onClick={closePreview}
            aria-label="Close full-screen preview"
          >
            <X aria-hidden="true" />
          </button>
          <figure
            className={`preview-figure ${resolution === "mobile" ? "mobile-preview" : ""}`}
          >
            <img
              src={wallpaper.image}
              alt={`Full-screen view of ${wallpaper.title}${
                wallpaper.location ? `, ${wallpaper.location}` : ""
              }`}
              width={SOURCE_WIDTH}
              height={SOURCE_HEIGHT}
            />
            <figcaption className="preview-caption">
              {wallpaper.title}
              {wallpaper.location ? ` — ${wallpaper.location}` : ""} ·{" "}
              {SOURCE_WIDTH} × {SOURCE_HEIGHT} master · press Escape to close
            </figcaption>
          </figure>
        </div>
      ) : null}
    </div>
  );
}
