CREATE TABLE `collections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(96) NOT NULL,
	`name` varchar(160) NOT NULL,
	`tagline` text,
	`description` text,
	`location` varchar(160),
	`coordinates` varchar(96),
	`heroImage` text,
	`accent` varchar(24) DEFAULT '#C9612A',
	`chapter` varchar(32),
	`featured` boolean NOT NULL DEFAULT false,
	`sortOrder` int NOT NULL DEFAULT 0,
	CONSTRAINT `collections_id` PRIMARY KEY(`id`),
	CONSTRAINT `collections_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `newsletterSubscribers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `newsletterSubscribers_id` PRIMARY KEY(`id`),
	CONSTRAINT `newsletterSubscribers_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `orderItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`wallpaperId` int NOT NULL,
	`resolution` varchar(24) NOT NULL,
	`license` varchar(24) NOT NULL,
	`unitPriceCents` int NOT NULL,
	`quantity` int NOT NULL DEFAULT 1,
	CONSTRAINT `orderItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reference` varchar(24) NOT NULL,
	`email` varchar(320) NOT NULL,
	`name` varchar(160) NOT NULL,
	`country` varchar(96),
	`subtotalCents` int NOT NULL,
	`totalCents` int NOT NULL,
	`status` varchar(24) NOT NULL DEFAULT 'paid',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_reference_unique` UNIQUE(`reference`)
);
--> statement-breakpoint
CREATE TABLE `wallpapers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(96) NOT NULL,
	`title` varchar(160) NOT NULL,
	`subtitle` varchar(200),
	`collectionId` int NOT NULL,
	`image` text NOT NULL,
	`thumb` text,
	`description` text,
	`location` varchar(160),
	`coordinates` varchar(96),
	`palettes` varchar(200) NOT NULL DEFAULT '',
	`basePriceCents` int NOT NULL DEFAULT 2800,
	`aspect` varchar(16) DEFAULT '16:9',
	`featured` boolean NOT NULL DEFAULT false,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wallpapers_id` PRIMARY KEY(`id`),
	CONSTRAINT `wallpapers_slug_unique` UNIQUE(`slug`)
);
