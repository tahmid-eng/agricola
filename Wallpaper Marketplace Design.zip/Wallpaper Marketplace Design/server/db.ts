import { and, asc, desc, eq, ne, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  collections,
  newsletterSubscribers,
  orderItems,
  orders,
  users,
  wallpapers,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    throw new Error("Database is not available");
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/* -------------------------------------------------------------------------- */
/*                                 Catalogue                                  */
/* -------------------------------------------------------------------------- */

const wallpaperProjection = {
  id: wallpapers.id,
  slug: wallpapers.slug,
  title: wallpapers.title,
  subtitle: wallpapers.subtitle,
  image: wallpapers.image,
  thumb: wallpapers.thumb,
  description: wallpapers.description,
  location: wallpapers.location,
  coordinates: wallpapers.coordinates,
  palettes: wallpapers.palettes,
  basePriceCents: wallpapers.basePriceCents,
  aspect: wallpapers.aspect,
  featured: wallpapers.featured,
  sortOrder: wallpapers.sortOrder,
  collectionId: wallpapers.collectionId,
  collectionSlug: collections.slug,
  collectionName: collections.name,
  collectionChapter: collections.chapter,
};

export type CatalogueWallpaper = {
  id: number;
  slug: string;
  title: string;
  subtitle: string | null;
  image: string;
  thumb: string | null;
  description: string | null;
  location: string | null;
  coordinates: string | null;
  palettes: string;
  basePriceCents: number;
  aspect: string | null;
  featured: boolean;
  sortOrder: number;
  collectionId: number;
  collectionSlug: string | null;
  collectionName: string | null;
  collectionChapter: string | null;
};

export async function listCollections() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(collections).orderBy(asc(collections.sortOrder));
}

export async function getCollectionBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select()
    .from(collections)
    .where(eq(collections.slug, slug))
    .limit(1);
  return rows[0];
}

export async function listWallpapers(): Promise<CatalogueWallpaper[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select(wallpaperProjection)
    .from(wallpapers)
    .leftJoin(collections, eq(collections.id, wallpapers.collectionId))
    .orderBy(asc(wallpapers.sortOrder), asc(wallpapers.id));
  return rows;
}

export async function getWallpaperBySlug(
  slug: string
): Promise<CatalogueWallpaper | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select(wallpaperProjection)
    .from(wallpapers)
    .leftJoin(collections, eq(collections.id, wallpapers.collectionId))
    .where(eq(wallpapers.slug, slug))
    .limit(1);
  return rows[0];
}

export async function listWallpapersByCollection(collectionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select(wallpaperProjection)
    .from(wallpapers)
    .leftJoin(collections, eq(collections.id, wallpapers.collectionId))
    .where(eq(wallpapers.collectionId, collectionId))
    .orderBy(asc(wallpapers.sortOrder));
}

export async function listRelatedWallpapers(
  collectionId: number,
  excludeId: number,
  limit = 3
): Promise<CatalogueWallpaper[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select(wallpaperProjection)
    .from(wallpapers)
    .leftJoin(collections, eq(collections.id, wallpapers.collectionId))
    .where(
      and(
        eq(wallpapers.collectionId, collectionId),
        ne(wallpapers.id, excludeId)
      )
    )
    .orderBy(asc(wallpapers.sortOrder), asc(wallpapers.id))
    .limit(limit);
}

/* -------------------------------------------------------------------------- */
/*                                  Orders                                    */
/* -------------------------------------------------------------------------- */

export async function createOrder(input: {
  reference: string;
  email: string;
  name: string;
  country: string | null;
  subtotalCents: number;
  totalCents: number;
  items: {
    wallpaperId: number;
    resolution: string;
    license: string;
    unitPriceCents: number;
    quantity: number;
  }[];
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  return db.transaction(async tx => {
    const [created] = await tx.insert(orders).values({
      reference: input.reference,
      email: input.email,
      name: input.name,
      country: input.country,
      subtotalCents: input.subtotalCents,
      totalCents: input.totalCents,
      status: "paid",
    });

    const orderId = Number(created.insertId);
    await tx.insert(orderItems).values(
      input.items.map(item => ({
        orderId,
        wallpaperId: item.wallpaperId,
        resolution: item.resolution,
        license: item.license,
        unitPriceCents: item.unitPriceCents,
        quantity: item.quantity,
      }))
    );
    return { orderId, reference: input.reference };
  });
}

export async function getOrderByReference(reference: string) {
  const db = await getDb();
  if (!db) return undefined;

  const rows = await db
    .select()
    .from(orders)
    .where(eq(orders.reference, reference))
    .limit(1);
  const order = rows[0];
  if (!order) return undefined;

  const items = await db
    .select({
      id: orderItems.id,
      resolution: orderItems.resolution,
      license: orderItems.license,
      unitPriceCents: orderItems.unitPriceCents,
      quantity: orderItems.quantity,
      wallpaperId: orderItems.wallpaperId,
      title: wallpapers.title,
      slug: wallpapers.slug,
      image: wallpapers.image,
      thumb: wallpapers.thumb,
      location: wallpapers.location,
    })
    .from(orderItems)
    .leftJoin(wallpapers, eq(wallpapers.id, orderItems.wallpaperId))
    .where(eq(orderItems.orderId, order.id))
    .orderBy(asc(orderItems.id));

  return { order, items };
}

export async function countOrders() {
  const db = await getDb();
  if (!db) return 0;
  const rows = await db.select({ value: sql<number>`count(*)` }).from(orders);
  return Number(rows[0]?.value ?? 0);
}

/* -------------------------------------------------------------------------- */
/*                                 Newsletter                                 */
/* -------------------------------------------------------------------------- */

export async function subscribeToNewsletter(email: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .insert(newsletterSubscribers)
    .values({ email })
    .onDuplicateKeyUpdate({ set: { email } });
}
