import { describe, expect, it } from "vitest";
import {
  computeUnitPriceCents,
  formatPrice,
  makeOrderReference,
} from "../shared/market";

describe("market pricing", () => {
  it("uses matching browser/server pricing for the base desktop licence", () => {
    expect(computeUnitPriceCents(3200, "desktop", "personal")).toBe(3200);
    expect(computeUnitPriceCents(3200, "mobile", "personal")).toBe(2400);
    expect(computeUnitPriceCents(3200, "8k", "personal")).toBe(5600);
  });
  it("rounds commercial pricing to 50 cents and formats cents", () => {
    expect(computeUnitPriceCents(3200, "desktop", "commercial")).toBe(7700);
    expect(formatPrice(7700)).toBe("$77");
    expect(formatPrice(5750)).toBe("$57.50");
  });
  it("creates a bearer reference within the persisted field limit", () => {
    const value = makeOrderReference(() => 0);
    expect(value).toMatch(/^EL-[A-Z2-9]{6}-[A-Z2-9]{6}-[A-Z2-9]{4}$/);
    expect(value.length).toBeLessThanOrEqual(24);
  });
});
