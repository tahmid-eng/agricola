import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({ artwork: vi.fn(), writeOrder: vi.fn() }));
vi.mock("./db", () => ({
  getWallpaperBySlug: mocks.artwork,
  createOrder: mocks.writeOrder,
  getOrderByReference: vi.fn(),
  listCollections: vi.fn(),
  getCollectionBySlug: vi.fn(),
  listWallpapers: vi.fn(),
  listWallpapersByCollection: vi.fn(),
  listRelatedWallpapers: vi.fn(),
  subscribeToNewsletter: vi.fn(),
}));
import { appRouter } from "./routers";
const ctx = { user: null, req: { headers: {} }, res: {} } as TrpcContext;
const input = {
  customer: { name: "Demo Visitor", email: "demo@example.com", country: "UK" },
  items: [
    {
      slug: "vaud-no-01",
      resolution: "desktop",
      license: "personal",
      quantity: 1,
    },
  ],
  expectedTotalCents: 3200,
};

beforeEach(() => {
  mocks.artwork.mockReset().mockResolvedValue({ id: 1, basePriceCents: 3200 });
  mocks.writeOrder
    .mockReset()
    .mockImplementation(async (order: { reference: string }) => ({
      orderId: 1,
      reference: order.reference,
    }));
});

describe("demo order pricing (no database writes)", () => {
  it("records only the server-calculated price and valid variants", async () => {
    const result = await appRouter.createCaller(ctx).orders.create(input);
    expect(result.totalCents).toBe(3200);
    expect(mocks.writeOrder).toHaveBeenCalledOnce();
    expect(mocks.writeOrder.mock.calls[0][0].items[0].unitPriceCents).toBe(
      3200
    );
  });
  it("rejects a changed total before creating an order", async () => {
    await expect(
      appRouter
        .createCaller(ctx)
        .orders.create({ ...input, expectedTotalCents: 100 })
    ).rejects.toMatchObject({ code: "CONFLICT" });
    expect(mocks.writeOrder).not.toHaveBeenCalled();
  });
  it("rejects invalid quantities before pricing or persistence", async () => {
    await expect(
      appRouter
        .createCaller(ctx)
        .orders.create({
          ...input,
          items: [{ ...input.items[0], quantity: 0 }],
        })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mocks.writeOrder).not.toHaveBeenCalled();
  });
});
