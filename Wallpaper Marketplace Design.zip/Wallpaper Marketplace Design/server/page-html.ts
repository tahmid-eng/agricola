import {
  getCollectionBySlug,
  getWallpaperBySlug,
  listCollections,
  listWallpapers,
  listWallpapersByCollection,
  type CatalogueWallpaper,
} from "./db";

const escape = (value: string | number | null | undefined) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    c =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!
  );
const header = `<header class="site-header solid-header"><a href="/" class="wordmark">elsewhere.</a><nav class="desktop-nav" aria-label="Main navigation"><a href="/shop">Wallpapers.</a><a href="/collections">Collections.</a><a href="/journal">Journal.</a><a href="/about">Our Story.</a></nav><a class="button button-blue" href="/shop">Find your elsewhere</a></header>`;
function cards(artworks: CatalogueWallpaper[]) {
  return `<div class="art-grid">${artworks.map(art => `<article class="art-card"><a href="/wallpaper/${escape(art.slug)}" class="art-card-image"><img src="${escape(art.thumb || art.image)}" alt="Illustrated landscape of ${escape(art.location)}" /></a><div class="art-card-meta"><div><p class="eyebrow">${escape(art.collectionName)}</p><a href="/wallpaper/${escape(art.slug)}"><h3>${escape(art.title)}</h3></a><p class="art-card-location">${escape(art.location)}</p></div><span>$${escape(art.basePriceCents / 100)}</span></div></article>`).join("")}</div>`;
}
const titles: Record<string, [string, string]> = {
  "/journal": [
    "The field notes.",
    "Places, colours, and things we noticed along the way. A small journal for the beautifully distracted.",
  ],
  "/journal/the-art-of-looking": [
    "The art of looking a little longer.",
    "A morning in the cedar mist, and a small reminder that the best things don't announce themselves.",
  ],
  "/journal/a-colour-called-elsewhere": [
    "A colour called elsewhere.",
    "On ultramarine, afternoon light, and the palette we always seem to come home with.",
  ],
  "/journal/the-long-way-north": [
    "Taking the long way north.",
    "Red cabins, a light that wouldn't leave, and the beauty of having nowhere to hurry to.",
  ],
  "/about": [
    "We make places you can keep.",
    "Elsewhere is a collection of original illustrated landscapes, made for the screens we live with. For the days when you can't go far, but your mind would like to.",
  ],
  "/policies/licensing": [
    "A place to call your own.",
    "Personal and commercial licensing for illustrated wallpapers. Original artwork is 2560 × 1440; larger formats are resized exports. This is a demo storefront with no paid licence agreement.",
  ],
  "/policies/faq": [
    "A few good questions.",
    "Digital wallpaper downloads for your screen, not physical wall coverings. Demo checkout does not charge money. JPEG exports are created in your browser.",
  ],
  "/policies/privacy": [
    "A little privacy, please.",
    "Demo orders store your name, email, country and chosen artwork. Saved artwork and your bag stay in your browser. We never collect card details.",
  ],
};

export async function renderPageHtml(template: string, requestUrl: string) {
  const path =
    new URL(requestUrl, "http://internal").pathname.replace(/\/$/, "") || "/";
  let title = "Elsewhere — Original Art for Everyday Escapes";
  let description =
    "Find your elsewhere. Original illustrated landscape wallpapers for desktop and mobile — from alpine mornings to Mediterranean afternoons.";
  let content = "";
  let status = 200;
  let privatePage = false;
  if (path === "/") {
    const artworks = await listWallpapers();
    content = `<main><section class="hero"><div class="hero-art"><img class="active" src="/manus-storage/alpine-full_92c07a49.jpg" alt="Illustrated alpine landscape" /></div><div class="hero-shade"></div><div class="hero-copy"><p class="eyebrow">A DIFFERENT KIND OF WALLPAPER</p><h1>Get Lost.<br>Feel Found.</h1><p class="hero-description">For the places you'd rather be.<br>Artful wallpapers for a little everyday escape.</p><div class="hero-ctas"><a class="button button-cream" href="/shop">Find your elsewhere ↗</a><a class="line-link" href="/collection/alpine">Explore the collection →</a></div></div></section><section class="featured-section" style="padding-top:65px"><div class="section-heading"><h2>Somewhere for you.</h2></div>${cards(artworks.slice(0, 3))}</section></main>`;
  } else if (path === "/shop") {
    title = "Find Your Elsewhere — Original Digital Wallpapers";
    content = `<main><section class="page-intro"><p class="eyebrow">YOUR NEXT LITTLE ESCAPE</p><h1>Find your <em>elsewhere.</em></h1><p>From alpine mornings to endless summer afternoons. A world of original art, made for your screen.</p></section><section class="shop-section">${cards(await listWallpapers())}</section></main>`;
  } else if (path === "/collections") {
    title = "A World in Chapters — Elsewhere Collections";
    const chapters = await listCollections();
    content = `<main><section class="page-intro"><p class="eyebrow">A WORLD, IN CHAPTERS</p><h1>Follow your <em>feeling.</em></h1></section><div class="collection-list">${chapters.map(ch => `<a class="collection-editorial" href="/collection/${escape(ch.slug)}"><div class="collection-editorial-image"><img src="${escape(ch.heroImage)}" alt="${escape(ch.name)}"></div><div class="collection-editorial-copy"><p class="eyebrow">${escape(ch.chapter)}</p><h2>${escape(ch.name)}</h2><p>${escape(ch.tagline)}</p><span class="line-link">Wander this chapter →</span></div></a>`).join("")}</div></main>`;
  } else if (path.startsWith("/wallpaper/")) {
    const art = await getWallpaperBySlug(decodeURIComponent(path.slice(11)));
    if (!art) status = 404;
    else {
      title = `${art.title} — Elsewhere Illustrated Wallpaper`;
      description = art.subtitle || description;
      content = `<main class="commerce-page"><div class="product-layout"><div class="product-visual"><img src="${escape(art.image)}" alt="${escape(art.title)}" /></div><div class="product-info"><p class="eyebrow">${escape(art.collectionName)}</p><h1 class="display-title">${escape(art.title)}</h1><p class="lead">${escape(art.subtitle)}</p><p>${escape(art.description)}</p><p class="product-location">${escape(art.location)} · ${escape(art.coordinates)}</p><h2>Make it your elsewhere.</h2><p class="lead">From $${escape(art.basePriceCents / 100)}. Desktop, mobile and 8K resized exports. Personal and commercial licence options.</p><p class="notice">Demo checkout — no money is charged. Original artwork: 2560 × 1440 pixels.</p><a class="line-link" href="/collection/${escape(art.collectionSlug)}">Explore the chapter →</a></div></div></main>`;
    }
  } else if (path.startsWith("/collection/")) {
    const ch = await getCollectionBySlug(decodeURIComponent(path.slice(12)));
    if (!ch) status = 404;
    else {
      title = `${ch.name} — Elsewhere Wallpaper Collection`;
      description = ch.tagline || description;
      content = `<main><section class="collection-hero"><img src="${escape(ch.heroImage)}" alt="${escape(ch.name)}"/><div class="collection-hero-shade"></div><div><p class="eyebrow">${escape(ch.chapter)}</p><h1>${escape(ch.name)}</h1><p>${escape(ch.tagline)}</p></div></section><section class="collection-intro"><p class="eyebrow">A NOTE FROM THE ATELIER</p><p>${escape(ch.description)}</p></section><section class="featured-section">${cards(await listWallpapersByCollection(ch.id))}</section></main>`;
    }
  } else if (titles[path]) {
    const entry = titles[path];
    title = `${entry[0]} — Elsewhere Atelier`;
    description = entry[1];
    content = `<main><section class="page-intro"><p class="eyebrow">THE ELSEWHERE ATELIER</p><h1>${escape(entry[0])}</h1><p>${escape(entry[1])}</p></section><div class="policy-content"><h2>A little off the beaten path.</h2><p>Original illustrated landscapes, generous colour, visible grain, and places that feel remembered rather than recorded.</p><p><a class="line-link" href="/shop">Explore the wallpapers →</a></p>${
      path === "/journal"
        ? Object.entries(titles)
            .filter(([url]) => url.startsWith("/journal/"))
            .map(
              ([url, entry]) =>
                `<section><a href="${url}"><h2>${escape(entry[0])}</h2><p>${escape(entry[1])}</p></a></section>`
            )
            .join("")
        : ""
    }</div></main>`;
  } else if (
    path === "/saved" ||
    path === "/checkout" ||
    path.startsWith("/order/")
  ) {
    privatePage = true;
    title = "Your Elsewhere — Wallpaper Atelier";
    content = `<main class="page-state"><h1>Your little elsewhere.</h1><p>This private browser experience needs JavaScript.</p><a class="line-link" href="/shop">Explore the wallpapers →</a></main>`;
  } else status = 404;
  if (status === 404) {
    title = "Off the Map — Elsewhere Atelier";
    description = "This place is not in the archive.";
    content = `<main class="page-state"><h1>A little off the map.</h1><p>That place isn't in our archive.</p><a class="button button-blue" href="/">Back to elsewhere</a></main>`;
  }
  const robots =
    privatePage || status !== 200 ? "noindex, nofollow" : "index, follow";
  let html = template
    .replace(/<title>.*?<\/title>/, `<title>${escape(title)}</title>`)
    .replace(
      /<meta name="description" content="[^"]*"\s*\/>/,
      `<meta name="description" content="${escape(description)}" />`
    )
    .replace(
      /<meta property="og:title" content="[^"]*"\s*\/>/,
      `<meta property="og:title" content="${escape(title)}" />`
    )
    .replace(
      /<meta property="og:description" content="[^"]*"\s*\/>/,
      `<meta property="og:description" content="${escape(description)}" />`
    );
  html = html
    .replace("</head>", `<meta name="robots" content="${robots}" /></head>`)
    .replace(
      '<div id="root"></div>',
      `<div id="root">${header}${content}</div>`
    );
  return { html, status, privatePage };
}
