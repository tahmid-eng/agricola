import { COOKIE_NAME } from "@shared/const";
import {
  LICENSE_IDS,
  RESOLUTION_IDS,
  computeUnitPriceCents,
  makeOrderReference,
} from "@shared/market";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import {
  createOrder,
  getCollectionBySlug,
  getOrderByReference,
  getWallpaperBySlug,
  listCollections,
  listRelatedWallpapers,
  listWallpapers,
  listWallpapersByCollection,
  subscribeToNewsletter,
} from "./db";

const checkoutItemSchema = z.object({
  slug: z.string().min(1).max(96),
  resolution: z.enum(RESOLUTION_IDS as [string, ...string[]]),
  license: z.enum(LICENSE_IDS as [string, ...string[]]),
  quantity: z.number().int().min(1).max(10),
});

const customerSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Please tell us who the licence is for.")
    .max(120),
  email: z
    .string()
    .trim()
    .email("That email address doesn't look right.")
    .max(320),
  country: z.string().trim().min(2).max(96),
});

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  catalog: router({
    collections: publicProcedure.query(() => listCollections()),

    wallpapers: publicProcedure.query(() => listWallpapers()),

    featured: publicProcedure.query(async () => {
      const [allCollections, allWallpapers] = await Promise.all([
        listCollections(),
        listWallpapers(),
      ]);
      return {
        collections: allCollections.filter(collection => collection.featured),
        wallpapers: allWallpapers.filter(wallpaper => wallpaper.featured),
        allCollections,
      };
    }),

    wallpaper: publicProcedure
      .input(z.object({ slug: z.string().min(1).max(96) }))
      .query(async ({ input }) => {
        const wallpaper = await getWallpaperBySlug(input.slug);
        if (!wallpaper) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "That place isn't in the archive.",
          });
        }
        const related = await listRelatedWallpapers(
          wallpaper.collectionId,
          wallpaper.id,
          3
        );
        return { wallpaper, related };
      }),

    collection: publicProcedure
      .input(z.object({ slug: z.string().min(1).max(96) }))
      .query(async ({ input }) => {
        const collection = await getCollectionBySlug(input.slug);
        if (!collection) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "That chapter hasn't been printed yet.",
          });
        }
        const artworks = await listWallpapersByCollection(collection.id);
        return { collection, wallpapers: artworks };
      }),
  }),

  orders: router({
    create: publicProcedure
      .input(
        z.object({
          customer: customerSchema,
          items: z.array(checkoutItemSchema).min(1).max(100),
          expectedTotalCents: z.number().int().nonnegative(),
          note: z.string().max(280).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const priced = [];
        for (const item of input.items) {
          const wallpaper = await getWallpaperBySlug(item.slug);
          if (!wallpaper) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: `“${item.slug}” is no longer available. Please remove it from your cart.`,
            });
          }
          priced.push({
            wallpaperId: wallpaper.id,
            resolution: item.resolution,
            license: item.license,
            unitPriceCents: computeUnitPriceCents(
              wallpaper.basePriceCents,
              item.resolution,
              item.license
            ),
            quantity: item.quantity,
          });
        }

        // Digital goods: a single price per licence, no tax model in this demo.
        const subtotalCents = priced.reduce(
          (sum, item) => sum + item.unitPriceCents * item.quantity,
          0
        );
        if (subtotalCents !== input.expectedTotalCents) {
          throw new TRPCError({
            code: "CONFLICT",
            message:
              "The atelier has updated these prices. Please review the refreshed total before trying again.",
          });
        }

        let reference = makeOrderReference();
        let created: { orderId: number; reference: string } | null = null;
        for (let attempt = 0; attempt < 4 && !created; attempt += 1) {
          try {
            created = await createOrder({
              reference,
              email: input.customer.email,
              name: input.customer.name,
              country: input.customer.country,
              subtotalCents,
              totalCents: subtotalCents,
              items: priced,
            });
          } catch (error) {
            const message = error instanceof Error ? error.message : "";
            if (!message.includes("Duplicate")) throw error;
            reference = makeOrderReference();
          }
        }

        if (!created) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "We couldn't open your order. Please try again.",
          });
        }

        return { reference: created.reference, totalCents: subtotalCents };
      }),

    get: publicProcedure
      .input(z.object({ reference: z.string().min(4).max(24) }))
      .query(async ({ input }) => {
        const found = await getOrderByReference(input.reference.toUpperCase());
        if (!found) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "No order with that reference.",
          });
        }
        return found;
      }),
  }),

  newsletter: router({
    subscribe: publicProcedure
      .input(
        z.object({
          email: z
            .string()
            .trim()
            .email("That email address doesn't look right."),
        })
      )
      .mutation(async ({ input }) => {
        await subscribeToNewsletter(input.email.toLowerCase());
        return { ok: true } as const;
      }),
  }),
});

export type AppRouter = typeof appRouter;
