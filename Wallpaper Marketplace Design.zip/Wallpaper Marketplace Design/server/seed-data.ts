/**
 * The house catalogue: five chapters, ten places.
 * Image paths are Webdev project storage keys returned by `manus-upload-file --webdev`.
 */

const storage = (file: string) => `/manus-storage/${file}`;

export type SeedCollection = {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  location: string;
  coordinates: string;
  heroImage: string;
  accent: string;
  chapter: string;
  featured: boolean;
  sortOrder: number;
};

export type SeedWallpaper = {
  slug: string;
  title: string;
  subtitle: string;
  collection: string;
  image: string;
  thumb: string;
  description: string;
  location: string;
  coordinates: string;
  palettes: string;
  basePriceCents: number;
  featured: boolean;
  sortOrder: number;
};

const artworkKeys: Record<string, { image: string; thumb: string }> = {
  alpine: {
    image: storage("alpine-full_92c07a49.jpg"),
    thumb: storage("alpine-card_4a7bab77.jpg"),
  },
  amalfi: {
    image: storage("amalfi-full_fb8db0af.jpg"),
    thumb: storage("amalfi-card_b0d9131f.jpg"),
  },
  bali: {
    image: storage("bali-full_9c9ad6f8.jpg"),
    thumb: storage("bali-card_89f9a09a.jpg"),
  },
  cyclades: {
    image: storage("cyclades-full_334c607c.jpg"),
    thumb: storage("cyclades-card_61a9d233.jpg"),
  },
  highlands: {
    image: storage("highlands-full_61d73aca.jpg"),
    thumb: storage("highlands-card_630aa9af.jpg"),
  },
  kyoto: {
    image: storage("kyoto-full_27ab7df6.jpg"),
    thumb: storage("kyoto-card_4306ce7f.jpg"),
  },
  lofoten: {
    image: storage("lofoten-full_b6b4b561.jpg"),
    thumb: storage("lofoten-card_3cf90f27.jpg"),
  },
  marrakech: {
    image: storage("marrakech-full_309da026.jpg"),
    thumb: storage("marrakech-card_42d67dd2.jpg"),
  },
  patagonia: {
    image: storage("patagonia-full_e5329c8b.jpg"),
    thumb: storage("patagonia-card_9a90dd34.jpg"),
  },
  sahara: {
    image: storage("sahara-full_2df7858c.jpg"),
    thumb: storage("sahara-card_d2a21277.jpg"),
  },
};

const art = (slug: string) => artworkKeys[slug];

export const seedCollections: SeedCollection[] = [
  {
    slug: "alpine",
    name: "The Alpine Chapter",
    tagline: "Cold air, long light, and the sound of nothing.",
    description:
      "Where the road runs out and the mountains begin. Painted from a week of walking between Vaud and the Torres del Paine, this chapter is about altitude and the particular silence that arrives above the tree line. Snow holds the last of the sunset; the meadows keep the rest.",
    location: "Vaud, Switzerland",
    coordinates: "46°33'N · 06°48'E",
    heroImage: storage("alpine-full_92c07a49.jpg"),
    accent: "#C9612A",
    chapter: "Chapter 01",
    featured: true,
    sortOrder: 1,
  },
  {
    slug: "mediterranean",
    name: "The Middle Sea",
    tagline: "Salt on the shutters, lemons in the shade.",
    description:
      "A coast painted from memory: white walls, impossible water, the heat coming off stone at four in the afternoon. We followed the shoreline from the Amalfi cliffs to the Cyclades and brought back the colours that only exist for an hour before dusk.",
    location: "Amalfi Coast, Italy",
    coordinates: "40°38'N · 14°36'E",
    heroImage: storage("amalfi-full_fb8db0af.jpg"),
    accent: "#D9A43C",
    chapter: "Chapter 02",
    featured: true,
    sortOrder: 2,
  },
  {
    slug: "east",
    name: "The Quiet East",
    tagline: "Mist, vermilion, and the first light on water.",
    description:
      "Two mornings, four thousand miles apart, that feel like the same dream. Cedar fog in Kyoto; rice terraces catching the sun in Ubud. This chapter is deliberately still — a place to put your work, and then look past it.",
    location: "Kyoto, Japan",
    coordinates: "35°00'N · 135°46'E",
    heroImage: storage("kyoto-full_27ab7df6.jpg"),
    accent: "#B4442E",
    chapter: "Chapter 03",
    featured: true,
    sortOrder: 3,
  },
  {
    slug: "south",
    name: "Warm Latitudes",
    tagline: "Dust, tiles, and the slow hour.",
    description:
      "Desert light and courtyard shade, painted in ochre and terracotta. The south is where we go to slow the clock down: dunes at sunset, a riad pool at noon, the smell of orange blossom drifting through an arch.",
    location: "Erg Chebbi, Morocco",
    coordinates: "31°09'N · 03°58'W",
    heroImage: storage("sahara-full_2df7858c.jpg"),
    accent: "#C9612A",
    chapter: "Chapter 04",
    featured: false,
    sortOrder: 4,
  },
  {
    slug: "north",
    name: "North of Here",
    tagline: "Weather, granite, and a light that refuses to leave.",
    description:
      "The far north in summer, when the sun only dips behind the ridge. Fjords the colour of ink, a castle in the heather, red cabins holding one warm window each. These are the wallpapers for people who like their quiet with a little weather in it.",
    location: "Lofoten, Norway",
    coordinates: "68°12'N · 14°28'E",
    heroImage: storage("lofoten-full_b6b4b561.jpg"),
    accent: "#7C8B5A",
    chapter: "Chapter 05",
    featured: false,
    sortOrder: 5,
  },
];

export const seedWallpapers: SeedWallpaper[] = [
  {
    slug: "vaud-no-01",
    title: "Vaud, No. 01",
    subtitle: "An alpine morning, held still.",
    collection: "alpine",
    ...art("alpine"),
    description:
      "Painted from a hillside above Lake Geneva, just after the cloud lifted. The farmhouse is real; the light is a slight exaggeration. Cream sky, ultramarine distance, and a meadow with more flowers than any meadow has ever had.",
    location: "Vaud, Switzerland",
    coordinates: "46°33'N · 06°48'E",
    palettes: "ultramarine,sage,terracotta",
    basePriceCents: 3200,
    featured: true,
    sortOrder: 1,
  },
  {
    slug: "amalfi-no-02",
    title: "Amalfi, No. 02",
    subtitle: "Lemon light on the Tyrrhenian.",
    collection: "mediterranean",
    ...art("amalfi"),
    description:
      "A cliffside village at the exact minute the sun drops behind the headland. Lemons in the foreground, boats asleep below, every wall the colour of a peach. We kept the halftone dots visible on purpose — it should feel printed, not photographed.",
    location: "Amalfi Coast, Italy",
    coordinates: "40°38'N · 14°36'E",
    palettes: "ultramarine,terracotta,rose",
    basePriceCents: 3400,
    featured: true,
    sortOrder: 2,
  },
  {
    slug: "kyoto-no-03",
    title: "Kyoto, No. 03",
    subtitle: "Ten thousand gates before sunrise.",
    collection: "east",
    ...art("kyoto"),
    description:
      "Fushimi Inari at 5:40am, when the path belongs to the mist and whoever is willing to get up for it. Vermilion against indigo cedar, a mountain pretending to be a print. Quiet enough to work in front of.",
    location: "Kyoto, Japan",
    coordinates: "35°00'N · 135°46'E",
    palettes: "ultramarine,rose,ink",
    basePriceCents: 3000,
    featured: true,
    sortOrder: 3,
  },
  {
    slug: "sahara-no-04",
    title: "Sahara, No. 04",
    subtitle: "The long light of the dunes.",
    collection: "south",
    ...art("sahara"),
    description:
      "Erg Chebbi, an hour before the sun goes. Two palms, one caravan, and a horizon that keeps rearranging itself. Printed in ochre, apricot and burnt sienna with a cool ultramarine shadow so the sand still feels like sand.",
    location: "Erg Chebbi, Morocco",
    coordinates: "31°09'N · 03°58'W",
    palettes: "terracotta,ochre,ink",
    basePriceCents: 2900,
    featured: false,
    sortOrder: 4,
  },
  {
    slug: "lofoten-no-05",
    title: "Lofoten, No. 05",
    subtitle: "Blue hour, held overnight.",
    collection: "north",
    ...art("lofoten"),
    description:
      "A fjord in the middle of June, when the light never quite commits to leaving. Red cabins, black water, snow still on the ridge. The most restful wallpaper we make, and the one our studio keeps on its own screens.",
    location: "Lofoten, Norway",
    coordinates: "68°12'N · 14°28'E",
    palettes: "ultramarine,ink,sage",
    basePriceCents: 3100,
    featured: true,
    sortOrder: 5,
  },
  {
    slug: "cyclades-no-06",
    title: "Cyclades, No. 06",
    subtitle: "White walls, impossible blue.",
    collection: "mediterranean",
    ...art("cyclades"),
    description:
      "The walk up from the port in Santorini, painted at noon with the shadows left in. Bougainvillea, blue domes, a sea so saturated it looks invented. Made for a big screen in a small room.",
    location: "Santorini, Greece",
    coordinates: "36°25'N · 25°26'E",
    palettes: "ultramarine,rose",
    basePriceCents: 3000,
    featured: false,
    sortOrder: 6,
  },
  {
    slug: "highlands-no-07",
    title: "Highlands, No. 07",
    subtitle: "Weather moving through the glen.",
    collection: "north",
    ...art("highlands"),
    description:
      "Skye, in the four seasons it manages before lunch. A ruin above the loch, heather in bloom, and a shaft of light that arrived for ninety seconds. Prints beautifully on a matte studio display.",
    location: "Isle of Skye, Scotland",
    coordinates: "57°16'N · 06°12'W",
    palettes: "sage,ultramarine,ochre",
    basePriceCents: 2900,
    featured: false,
    sortOrder: 7,
  },
  {
    slug: "bali-no-08",
    title: "Bali, No. 08",
    subtitle: "Terraces catching first light.",
    collection: "east",
    ...art("bali"),
    description:
      "Ubud at sunrise, before the scooters. Rice terraces in six shades of green, a volcano in the haze, palms doing their best silhouette. Warm without being loud — a good one for a room that gets no sun.",
    location: "Ubud, Bali",
    coordinates: "08°30'S · 115°15'E",
    palettes: "sage,ochre,terracotta",
    basePriceCents: 2800,
    featured: false,
    sortOrder: 8,
  },
  {
    slug: "marrakech-no-09",
    title: "Marrakech, No. 09",
    subtitle: "An afternoon behind the arch.",
    collection: "south",
    ...art("marrakech"),
    description:
      "A riad courtyard at the hour when everyone else is asleep. Zellige in cobalt and cream, orange trees in terracotta pots, one perfect rectangle of blue sky. Painted for anyone who works from a desk and would rather be somewhere warmer.",
    location: "Marrakech, Morocco",
    coordinates: "31°37'N · 07°59'W",
    palettes: "terracotta,ochre,ultramarine",
    basePriceCents: 2900,
    featured: false,
    sortOrder: 9,
  },
  {
    slug: "patagonia-no-10",
    title: "Patagonia, No. 10",
    subtitle: "Wind, granite, and impossible distance.",
    collection: "alpine",
    ...art("patagonia"),
    description:
      "Torres del Paine from the eastern shore, with the wind doing what it does. Ice in the lake, lenga trees bent flat, granite lit like a furnace at the top. The widest country we have ever painted.",
    location: "Torres del Paine, Chile",
    coordinates: "50°56'S · 73°24'W",
    palettes: "ultramarine,sage,ink",
    basePriceCents: 3200,
    featured: true,
    sortOrder: 10,
  },
];
