import "dotenv/config";
import { eq } from "drizzle-orm";
import { collections, wallpapers } from "../drizzle/schema";
import { getDb } from "./db";
import { seedCollections, seedWallpapers } from "./seed-data";

/**
 * Idempotent catalogue seed: safe to re-run, and never deletes shopper orders.
 * Run with: pnpm tsx server/seed.ts
 */
async function main() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL is not available");

  for (const collection of seedCollections) {
    await db
      .insert(collections)
      .values(collection)
      .onDuplicateKeyUpdate({
        set: {
          name: collection.name,
          tagline: collection.tagline,
          description: collection.description,
          location: collection.location,
          coordinates: collection.coordinates,
          heroImage: collection.heroImage,
          accent: collection.accent,
          chapter: collection.chapter,
          featured: collection.featured,
          sortOrder: collection.sortOrder,
        },
      });
  }

  const rows = await db.select().from(collections);
  const bySlug = new Map(rows.map(row => [row.slug, row.id]));

  for (const wallpaper of seedWallpapers) {
    const collectionId = bySlug.get(wallpaper.collection);
    if (!collectionId)
      throw new Error(`Unknown collection: ${wallpaper.collection}`);

    const values = {
      slug: wallpaper.slug,
      title: wallpaper.title,
      subtitle: wallpaper.subtitle,
      collectionId,
      image: wallpaper.image,
      thumb: wallpaper.thumb,
      description: wallpaper.description,
      location: wallpaper.location,
      coordinates: wallpaper.coordinates,
      palettes: wallpaper.palettes,
      basePriceCents: wallpaper.basePriceCents,
      aspect: "16:9",
      featured: wallpaper.featured,
      sortOrder: wallpaper.sortOrder,
    };

    await db
      .insert(wallpapers)
      .values(values)
      .onDuplicateKeyUpdate({
        set: {
          title: values.title,
          subtitle: values.subtitle,
          collectionId: values.collectionId,
          image: values.image,
          thumb: values.thumb,
          description: values.description,
          location: values.location,
          coordinates: values.coordinates,
          palettes: values.palettes,
          basePriceCents: values.basePriceCents,
          featured: values.featured,
          sortOrder: values.sortOrder,
        },
      });
  }

  const [{ total }] = await db
    .select({ total: wallpapers.id })
    .from(wallpapers)
    .where(eq(wallpapers.featured, true));

  console.log(
    `Seeded ${seedCollections.length} collections and ${seedWallpapers.length} wallpapers (featured sample id: ${total}).`
  );
  process.exit(0);
}

main().catch(error => {
  console.error(error);
  process.exit(1);
});
