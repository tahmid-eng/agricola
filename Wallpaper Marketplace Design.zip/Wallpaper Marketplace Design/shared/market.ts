/**
 * Shared catalog vocabulary and pricing rules.
 * The same math runs in the browser (display) and on the server (order totals),
 * so a tampered client can never change what an order actually costs.
 */

export type ResolutionId = "desktop" | "mobile" | "8k";
export type LicenseId = "personal" | "commercial";

export const RESOLUTIONS: {
  id: ResolutionId;
  label: string;
  pixels: string;
  note: string;
  multiplier: number;
}[] = [
  {
    id: "desktop",
    label: "Desktop 5K",
    pixels: "5120 × 2880",
    note: 'Retina displays, ultrawide, 27" and up',
    multiplier: 1,
  },
  {
    id: "mobile",
    label: "Mobile 4K",
    pixels: "1440 × 3120",
    note: "iPhone, Android, tablet lock screens",
    multiplier: 0.75,
  },
  {
    id: "8k",
    label: "8K Ultra",
    pixels: "7680 × 4320",
    note: "Studio displays, print, projection",
    multiplier: 1.75,
  },
];

export const LICENSES: {
  id: LicenseId;
  label: string;
  blurb: string;
  multiplier: number;
}[] = [
  {
    id: "personal",
    label: "Personal",
    blurb: "Your own devices, forever. No resale, no client work.",
    multiplier: 1,
  },
  {
    id: "commercial",
    label: "Commercial",
    blurb: "Client work, campaigns, interiors and screens up to 500k views.",
    multiplier: 2.4,
  },
];

export const PALETTES: { id: string; label: string; swatch: string }[] = [
  { id: "ultramarine", label: "Ultramarine", swatch: "#12249B" },
  { id: "terracotta", label: "Terracotta", swatch: "#C9612A" },
  { id: "sage", label: "Sage", swatch: "#7C8B5A" },
  { id: "ochre", label: "Ochre", swatch: "#D9A43C" },
  { id: "rose", label: "Rose", swatch: "#D98A7A" },
  { id: "ink", label: "Deep Ink", swatch: "#101322" },
];

export const RESOLUTION_IDS = RESOLUTIONS.map(r => r.id);
export const LICENSE_IDS = LICENSES.map(l => l.id);

export function resolutionById(id: string) {
  return RESOLUTIONS.find(r => r.id === id) ?? RESOLUTIONS[0];
}

export function licenseById(id: string) {
  return LICENSES.find(l => l.id === id) ?? LICENSES[0];
}

/** Rounded to the nearest 50 cents so prices read as designed, not as math. */
export function computeUnitPriceCents(
  basePriceCents: number,
  resolution: string,
  license: string
): number {
  const res = resolutionById(resolution);
  const lic = licenseById(license);
  const raw = basePriceCents * res.multiplier * lic.multiplier;
  return Math.round(raw / 50) * 50;
}

export function formatPrice(cents: number): string {
  const dollars = cents / 100;
  return `$${dollars % 1 === 0 ? dollars.toFixed(0) : dollars.toFixed(2)}`;
}

/** Unpredictable bearer reference; keep the receipt URL private. */
export function makeOrderReference(
  random: () => number = () => {
    const value = new Uint32Array(1);
    globalThis.crypto.getRandomValues(value);
    return value[0] / 2 ** 32;
  }
): string {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const block = (length: number) =>
    Array.from(
      { length },
      () => alphabet[Math.floor(random() * alphabet.length)]
    ).join("");
  return `EL-${block(6)}-${block(6)}-${block(4)}`;
}
